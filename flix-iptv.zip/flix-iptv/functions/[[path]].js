/**
 * Cloudflare Pages Functions - معالج المسار الديناميكي
 * يعمل كـ API backend للمشروع
 */

import { Router } from 'itty-router';

// إنشاء router
const router = Router();

// معالج للصفحة الرئيسية
router.get('/', (request) => {
    return new Response('Welcome to Flix-IPTV API', {
        status: 200,
        headers: { 'Content-Type': 'text/plain' }
    });
});

// إنشاء دفع جديد
router.post('/api/create-payment', async (request, env) => {
    try {
        const paymentData = await request.json();
        
        // التحقق من البيانات
        if (!paymentData || !paymentData.orderId) {
            return new Response(JSON.stringify({
                success: false,
                message: 'Invalid payment data'
            }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        // حفظ بيانات الطلب في KV
        await env.PAYMENTS_KV.put(
            `payment_${paymentData.orderId}`,
            JSON.stringify({
                ...paymentData,
                status: 'pending',
                createdAt: Date.now(),
                ip: request.headers.get('CF-Connecting-IP')
            }),
            { expirationTtl: 86400 } // انتهاء بعد 24 ساعة
        );
        
        // محاكاة إنشاء فاتورة NOWPayments
        // في الإنتاج، استخدم NOWPayments API الحقيقي
        const mockPaymentUrl = `https://nowpayments.io/payment/?iid=mock_${Date.now()}`;
        
        return new Response(JSON.stringify({
            success: true,
            paymentUrl: mockPaymentUrl,
            orderId: paymentData.orderId
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
});

// Webhook معالجة من NOWPayments
router.post('/api/payment-webhook', async (request, env) => {
    try {
        // التحقق من توقيع Webhook
        const signature = request.headers.get('x-nowpayments-sig');
        const payload = await request.text();
        
        // في الإنتاج، استخدم IPN_PIN للتحقق
        // const isValid = await verifyWebhookSignature(signature, payload, env.IPN_PIN);
        const isValid = true; // مؤقت للتنمية
        
        if (!isValid) {
            return new Response('Invalid signature', { status: 401 });
        }
        
        const webhookData = JSON.parse(payload);
        
        // التحقق من حالة الدفع
        if (webhookData.payment_status === 'finished') {
            // تحديث حالة الطلب في KV
            await env.PAYMENTS_KV.put(
                `payment_${webhookData.order_id}`,
                JSON.stringify({
                    ...webhookData,
                    status: 'completed',
                    completedAt: Date.now()
                })
            );
            
            // إرسال إشعار بالبريد الإلكتروني (محاكاة)
            await this.sendConfirmationEmail(webhookData, env);
        }
        
        return new Response('Webhook received', { status: 200 });
        
    } catch (error) {
        console.error('Webhook error:', error);
        return new Response('Error processing webhook', { status: 500 });
    }
});

// الحصول على حالة الدفع
router.get('/api/payment-status/:orderId', async (request, env) => {
    try {
        const { orderId } = request.params;
        
        // الحصول على بيانات الطلب من KV
        const paymentData = await env.PAYMENTS_KV.get(`payment_${orderId}`, 'json');
        
        if (!paymentData) {
            return new Response(JSON.stringify({
                success: false,
                message: 'Order not found'
            }), {
                status: 404,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        return new Response(JSON.stringify({
            success: true,
            order: paymentData
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
});

// حفظ بيانات الطلب
router.post('/api/save-order', async (request, env) => {
    try {
        const { orderId, orderData } = await request.json();
        
        await env.PAYMENTS_KV.put(
            `payment_${orderId}`,
            JSON.stringify(orderData),
            { expirationTtl: 604800 } // أسبوع
        );
        
        return new Response(JSON.stringify({
            success: true,
            message: 'Order saved'
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
});

// إرسال تأكيد بالبريد الإلكتروني
router.post('/api/send-confirmation', async (request, env) => {
    try {
        const { orderId, customerEmail, packageName, amount, currency } = await request.json();
        
        // في الإنتاج، استخدم خدمة بريد إلكتروني
        // هنا مجرد محاكاة
        console.log(`Email sent to ${customerEmail}: Order ${orderId} confirmed`);
        
        // حفظ في KV للتوثيق
        await env.USER_DATA.put(
            `email_${orderId}`,
            JSON.stringify({
                to: customerEmail,
                subject: 'Flix-IPTV Order Confirmation',
                sentAt: Date.now()
            })
        );
        
        return new Response(JSON.stringify({
            success: true,
            message: 'Confirmation sent'
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
});

// وظيفة مساعدة لإرسال البريد الإلكتروني
async function sendConfirmationEmail(webhookData, env) {
    // محاكاة إرسال البريد الإلكتروني
    // في الإنتاج، استخدم خدمة مثل SendGrid أو AWS SES
    
    const emailData = {
        to: webhookData.customer_email,
        subject: `Payment Confirmed - Order ${webhookData.order_id}`,
        body: `Your Flix-IPTV subscription has been activated.`,
        sentAt: Date.now()
    };
    
    await env.USER_DATA.put(
        `confirmation_${webhookData.order_id}`,
        JSON.stringify(emailData)
    );
}

// معالج الخطأ
router.all('*', () => {
    return new Response('Not Found', { status: 404 });
});

// تصدير معالج الطلبات
export default {
    fetch: router.handle
};