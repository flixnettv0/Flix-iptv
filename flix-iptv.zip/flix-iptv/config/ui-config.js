/**
 * تكوين واجهة المستخدم الديناميكي
 */

const UI_CONFIG = {
  // إعدادات الموقع
  site: {
    name: "Flix-IPTV",
    slogan: "All world packages in one subscription",
    logo_url: "/assets/images/logo.png",
    favicon_url: "/assets/images/favicon.ico",
    theme: "dark",
    direction: "auto" // auto, ltr, rtl
  },
  
  // مكونات الرأس
  header: {
    sticky: true,
    transparent_on_home: true,
    show_language_selector: true,
    show_user_menu: false,
    show_search: true,
    cta_button: {
      text: "Subscribe Now",
      url: "#subscribe",
      color: "primary"
    }
  },
  
  // مكونات التذييل
  footer: {
    show_newsletter: true,
    show_social_links: true,
    show_quick_links: true,
    show_copyright: true,
    columns: 4
  },
  
  // الصفحة الرئيسية
  homepage: {
    show_hero: true,
    show_stats: true,
    show_packages: true,
    show_activation: true,
    show_subscription: true,
    show_testimonials: false,
    show_partners: false,
    show_blog: false
  },
  
  // قسم الباقات
  packages_section: {
    show_search: true,
    show_categories: true,
    show_live_channels: true,
    show_epg: true,
    items_per_page: 12,
    grid_columns: {
      mobile: 1,
      tablet: 2,
      desktop: 3,
      large: 4
    }
  },
  
  // قسم التفعيل
  activation_section: {
    show_device_selector: true,
    show_mac_search: true,
    show_guides: true,
    devices_per_row: 6
  },
  
  // قسم الاشتراك
  subscription_section: {
    show_plans: true,
    show_payment_form: true,
    show_currency_selector: false,
    show_coupon_field: true,
    default_plan: "6m",
    highlight_popular: true
  },
  
  // أزرار الدفع
  payment_buttons: {
    primary_button: {
      text: "Subscribe Now",
      icon: "fas fa-credit-card",
      color: "primary",
      size: "lg",
      show_price: true,
      show_icons: true
    },
    secondary_button: {
      text: "Download App",
      icon: "fas fa-download",
      color: "secondary",
      size: "md"
    },
    trial_button: {
      text: "Start Free Trial",
      icon: "fas fa-play-circle",
      color: "success",
      size: "md",
      show_duration: true
    }
  },
  
  // طريقة عرض الباقات
  plan_display: {
    layout: "grid", // grid, list, cards
    show_features: true,
    show_savings: true,
    show_badge: true,
    show_button: true,
    show_trial_badge: true
  },
  
  // إعدادات الدفع
  payment_display: {
    show_logos: true,
    show_secure_badge: true,
    show_trust_icons: true,
    accepted_cards: ["visa", "mastercard", "amex", "discover"],
    payment_methods: ["card", "paypal", "crypto"],
    default_method: "card"
  },
  
  // الدعم والمساعدة
  support_widget: {
    enabled: true,
    position: "bottom-right",
    channels: ["telegram", "whatsapp", "messenger", "email"],
    show_auto_message: true,
    floating: true
  },
  
  // المساعد الذكي
  ai_helper: {
    enabled: true,
    position: "bottom-left",
    voice_enabled: false,
    quick_questions: ["install", "purchase", "devices", "troubleshoot"],
    show_voice_toggle: true
  },
  
  // التنبيهات والإشعارات
  notifications: {
    toast_position: "top-right",
    toast_duration: 5000,
    show_progress: true,
    types: {
      success: true,
      error: true,
      warning: true,
      info: true
    }
  },
  
  // التحميل والتظليل
  loading_indicators: {
    show_global_loader: true,
    show_button_loaders: true,
    show_skeleton_screens: true,
    spinner_type: "dots", // dots, ring, bars, pulse
    spinner_color: "primary"
  },
  
  // الرسوم المتحركة
  animations: {
    enabled: true,
    page_transitions: true,
    hover_effects: true,
    scroll_animations: true,
    reduced_motion: false
  },
  
  // التجاوب مع الأجهزة
  responsiveness: {
    mobile_breakpoint: 640,
    tablet_breakpoint: 768,
    desktop_breakpoint: 1024,
    large_breakpoint: 1280
  },
  
  // SEO وتحسين الأداء
  optimization: {
    lazy_loading: true,
    image_optimization: true,
    font_preloading: true,
    script_deferring: true,
    css_minification: true,
    cache_control: true
  },
  
  // التحليلات
  analytics: {
    enabled: true,
    track_events: true,
    track_errors: true,
    track_performance: true,
    anonymize_data: true,
    consent_required: true
  },
  
  // الوصول وميزات المساعدة
  accessibility: {
    keyboard_navigation: true,
    skip_to_content: true,
    aria_labels: true,
    high_contrast: false,
    font_scaling: true
  }
};

// وظائف مساعدة لواجهة المستخدم
UI_CONFIG.getResponsiveClass = function(breakpoint, prefix = "") {
  const classes = {
    "mobile": `${prefix}sm`,
    "tablet": `${prefix}md`,
    "desktop": `${prefix}lg`,
    "large": `${prefix}xl`
  };
  return classes[breakpoint] || "";
};

UI_CONFIG.getColorClass = function(color, type = "bg") {
  const colorMap = {
    "primary": `${type}-primary`,
    "secondary": `${type}-secondary`,
    "success": `${type}-success`,
    "warning": `${type}-warning`,
    "error": `${type}-error`,
    "info": `${type}-info`
  };
  return colorMap[color] || `${type}-primary`;
};

UI_CONFIG.getButtonSizeClass = function(size) {
  const sizeMap = {
    "xs": "px-2 py-1 text-xs",
    "sm": "px-3 py-1.5 text-sm",
    "md": "px-4 py-2 text-base",
    "lg": "px-6 py-3 text-lg",
    "xl": "px-8 py-4 text-xl"
  };
  return sizeMap[size] || "px-4 py-2 text-base";
};

UI_CONFIG.getGridColumnsClass = function(breakpoint) {
  const columns = this.packages_section.grid_columns[breakpoint] || 1;
  return `grid-cols-${columns}`;
};

// تصدير التكوين
module.exports = UI_CONFIG;