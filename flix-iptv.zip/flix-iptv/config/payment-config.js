// تكوين الباقات والأسعار
const PRICING_CONFIG = {
    packages: [
        {
            id: 'basic_3m',
            name: {
                en: '3 Months Plan',
                ar: 'باقة 3 أشهر',
                fr: 'Forfait 3 Mois',
                es: 'Plan 3 Meses',
                he: 'תוכנית ל-3 חודשים'
            },
            price: 25.00,
            currency: 'USD',
            duration: 3,
            features: [
                '250+ Live Channels',
                '5000+ VOD',
                'Support All Devices',
                '24/7 Support'
            ]
        },
        {
            id: 'standard_6m',
            name: {
                en: '6 Months Plan',
                ar: 'باقة 6 أشهر',
                fr: 'Forfait 6 Mois',
                es: 'Plan 6 Meses',
                he: 'תוכנית ל-6 חודשים'
            },
            price: 45.00,
            currency: 'USD',
            duration: 6,
            features: [
                'All Basic Features',
                '300+ Live Channels',
                '8000+ VOD',
                'Premium Sports',
                'Catch-up TV'
            ]
        },
        {
            id: 'premium_12m',
            name: {
                en: '12 Months Plan',
                ar: 'باقة 12 شهراً',
                fr: 'Forfait 12 Mois',
                es: 'Plan 12 Meses',
                he: 'תוכנית ל-12 חודשים'
            },
            price: 70.00,
            currency: 'USD',
            duration: 12,
            features: [
                'All Standard Features',
                '400+ Live Channels',
                '12000+ VOD',
                '4K Content Available',
                'Multi-screen (2 devices)',
                'Priority Support'
            ]
        }
    ],
    
    // إعدادات NOWPayments
    NOWPAYMENTS_CONFIG: {
        // هذه المفاتيح سيتم تعيينها كـ Secrets في Cloudflare
        apiUrl: 'https://api.nowpayments.io/v1',
        successUrl: '/success.html',
        cancelUrl: '/cancel.html',
        
        // العملات المدعومة
        currencies: [
            { code: 'USD', symbol: '$', name: 'US Dollar' },
            { code: 'BTC', symbol: '₿', name: 'Bitcoin' },
            { code: 'ETH', symbol: 'Ξ', name: 'Ethereum' },
            { code: 'USDT', symbol: '₮', name: 'Tether' },
            { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham' }
        ]
    },
    
    // إعدادات Cloudflare Turnstile
    TURNSTILE_CONFIG: {
        siteKey: 'YOUR_TURNSTILE_SITE_KEY', // سيتم تعيينه كـ Secret
        secretKey: 'YOUR_TURNSTILE_SECRET_KEY' // سيتم تعيينه كـ Secret
    }
};

module.exports = PRICING_CONFIG;