/**
 * ملف الترجمات متعدد اللغات لـ Flix-IPTV
 * يدعم 5 لغات: الإنجليزية، العربية، الفرنسية، الإسبانية، العبرية
 */

const TRANSLATIONS = {
    en: {
        // التنقل
        nav: {
            home: 'Home',
            packages: 'Packages',
            activation: 'Activation',
            support: 'Support',
            faq: 'FAQ',
            subscribe: 'Subscribe Now'
        },
        
        // القسم الرئيسي
        hero: {
            title: 'Premium IPTV Service for All Devices',
            description: 'Watch 400+ live channels, 12,000+ movies and TV shows in multiple languages. No contracts, cancel anytime.',
            channels: 'Live Channels',
            vod: 'Movies & TV Shows',
            support: 'Premium Support',
            countries: 'Countries',
            cta: 'Get Started Now'
        },
        
        // الباقات
        packages: {
            title: 'Choose Your Plan',
            subtitle: 'Select the perfect plan for your entertainment needs',
            perDuration: '/ month',
            select: 'Select Plan',
            recommended: 'Recommended',
            features: 'Features'
        },
        
        // التفعيل
        activation: {
            title: 'Device Activation',
            macTitle: 'Enter Your Device MAC Address',
            detect: 'Detect Device',
            macHint: 'Format: 00:1A:2B:3C:4D:5E or 00-1A-2B-3C-4D-5E',
            guidesTitle: 'Installation Guides',
            detected: 'Device Detected',
            mac: 'MAC Address',
            type: 'Device Type',
            status: 'Status',
            ready: 'Ready for Activation',
            viewGuide: 'View Installation Guide'
        },
        
        // الدفع
        payment: {
            title: 'Complete Your Subscription',
            summary: 'Order Summary',
            plan: 'Plan',
            price: 'Price',
            total: 'Total',
            paymentDetails: 'Payment Details',
            email: 'Email Address',
            method: 'Payment Method',
            creditCard: 'Credit/Debit Card',
            crypto: 'Cryptocurrency',
            selectCrypto: 'Select Cryptocurrency',
            proceed: 'Proceed to Payment',
            secure: '256-bit SSL Secure',
            encrypted: 'Encrypted Payment'
        },
        
        // الأسئلة الشائعة
        faq: {
            title: 'Frequently Asked Questions',
            q1: 'What devices are supported?',
            a1: 'We support all major devices: Android, iOS, Smart TVs, Fire Stick, MAG Box, Windows, and Mac. Detailed setup guides are available.',
            q2: 'How do I activate my service?',
            a2: 'After payment, enter your device\'s MAC address in the activation section. You\'ll receive your activation code immediately.',
            q3: 'What payment methods do you accept?',
            a3: 'We accept credit/debit cards (Visa, MasterCard) and major cryptocurrencies (Bitcoin, Ethereum, USDT) via secure payment gateway.',
            q4: 'Is there a free trial available?',
            a4: 'We offer a 24-hour trial for $1 to ensure service quality. This amount will be deducted from your first subscription.',
            q5: 'Can I use the service on multiple devices?',
            a5: 'The premium plan supports 2 simultaneous connections. Other plans support 1 connection.',
            q6: 'How do I get support?',
            a6: 'We offer 24/7 support via Telegram, WhatsApp, Messenger, and email.'
        },
        
        // مساعد الذكاء الاصطناعي
        ai: {
            title: 'AI Helper',
            placeholder: 'Ask me anything...',
            greeting: 'Hello! I\'m your AI assistant. How can I help you with Flix-IPTV?'
        },
        
        // التذييل
        footer: {
            description: 'Premium IPTV service with worldwide coverage and multi-language support.',
            links: 'Quick Links',
            packages: 'Packages',
            activation: 'Activation',
            faq: 'FAQ',
            terms: 'Terms of Service',
            privacy: 'Privacy Policy',
            contact: 'Contact Us',
            newsletter: 'Newsletter',
            newsletterDesc: 'Subscribe for updates and offers',
            emailPlaceholder: 'Your email',
            subscribe: 'Subscribe',
            copyright: '© 2024 Flix-IPTV. All rights reserved.'
        },
        
        // صفحات النجاح والإلغاء
        success: {
            title: 'Payment Successful!',
            message: 'Thank you for your purchase. Your subscription has been activated.',
            orderId: 'Order ID',
            activationCode: 'Activation Code',
            instructions: 'To activate your device:',
            step1: '1. Enter your MAC address in the activation section',
            step2: '2. Use the activation code above',
            step3: '3. Follow the device-specific installation guide',
            support: 'Need help? Contact our 24/7 support.',
            backHome: 'Back to Home'
        },
        
        cancel: {
            title: 'Payment Cancelled',
            message: 'Your payment was cancelled. No charges were made to your account.',
            reason: 'Possible reasons:',
            reason1: 'You cancelled the payment',
            reason2: 'Payment session expired',
            reason3: 'Technical issue',
            retry: 'Retry Payment',
            backHome: 'Back to Home'
        }
    },
    
    ar: {
        // التنقل
        nav: {
            home: 'الرئيسية',
            packages: 'الباقات',
            activation: 'التفعيل',
            support: 'الدعم',
            faq: 'الأسئلة الشائعة',
            subscribe: 'اشترك الآن'
        },
        
        // القسم الرئيسي
        hero: {
            title: 'خدمة IPTV متميزة لجميع الأجهزة',
            description: 'شاهد أكثر من 400 قناة بث مباشر، 12,000+ فيلم ومسلسل بعدة لغات. بدون عقود، يمكنك الإلغاء في أي وقت.',
            channels: 'قنوات مباشرة',
            vod: 'أفلام ومسلسلات',
            support: 'دعم فني متميز',
            countries: 'دولة',
            cta: 'ابدأ الآن'
        },
        
        // الباقات
        packages: {
            title: 'اختر خطتك',
            subtitle: 'اختر الخطة المثالية لاحتياجاتك الترفيهية',
            perDuration: '/ شهر',
            select: 'اختر الخطة',
            recommended: 'موصى بها',
            features: 'المميزات'
        },
        
        // التفعيل
        activation: {
            title: 'تفعيل الجهاز',
            macTitle: 'أدخل عنوان MAC لجهازك',
            detect: 'اكتشاف الجهاز',
            macHint: 'الصيغة: 00:1A:2B:3C:4D:5E أو 00-1A-2B-3C-4D-5E',
            guidesTitle: 'أدلة التثبيت',
            detected: 'تم اكتشاف الجهاز',
            mac: 'عنوان MAC',
            type: 'نوع الجهاز',
            status: 'الحالة',
            ready: 'جاهز للتفعيل',
            viewGuide: 'عرض دليل التثبيت'
        },
        
        // الدفع
        payment: {
            title: 'أكمل اشتراكك',
            summary: 'ملخص الطلب',
            plan: 'الخطة',
            price: 'السعر',
            total: 'المجموع',
            paymentDetails: 'تفاصيل الدفع',
            email: 'البريد الإلكتروني',
            method: 'طريقة الدفع',
            creditCard: 'بطاقة ائتمان/مدينة',
            crypto: 'عملات مشفرة',
            selectCrypto: 'اختر العملة المشفرة',
            proceed: 'المتابعة للدفع',
            secure: 'آمن بـ 256-bit SSL',
            encrypted: 'دفع مشفر'
        },
        
        // الأسئلة الشائعة
        faq: {
            title: 'الأسئلة الشائعة',
            q1: 'ما هي الأجهزة المدعومة؟',
            a1: 'نحن ندعم جميع الأجهزة الرئيسية: أندرويد، آيفون، التلفزيونات الذكية، فاير ستيك، أجهزة MAG، ويندوز، وماك. تتوفر أدلة إعداد مفصلة.',
            q2: 'كيف أقوم بتفعيل الخدمة؟',
            a2: 'بعد الدفع، أدخل عنوان MAC لجهازك في قسم التفعيل. ستحصل على كود التفعيل فوراً.',
            q3: 'ما هي طرق الدفع المقبولة؟',
            a3: 'نحن نقبل بطاقات الائتمان/الخصم (فيزا، ماستركارد) والعملات المشفرة الرئيسية (بيتكوين، إيثيريوم، USDT) عبر بوابة دفع آمنة.',
            q4: 'هل هناك تجربة مجانية متاحة؟',
            a4: 'نحن نقدم تجربة لمدة 24 ساعة مقابل 1 دولار لضمان جودة الخدمة. سيتم خصم هذا المبلغ من اشتراكك الأول.',
            q5: 'هل يمكنني استخدام الخدمة على أجهزة متعددة؟',
            a5: 'الخطة المتميزة تدعم اتصالين في نفس الوقت. الخطط الأخرى تدعم اتصالاً واحداً.',
            q6: 'كيف أحصل على الدعم؟',
            a6: 'نحن نقدم دعمًا على مدار الساعة عبر تلغرام، واتساب، ماسنجر، والبريد الإلكتروني.'
        },
        
        // مساعد الذكاء الاصطناعي
        ai: {
            title: 'المساعد الذكي',
            placeholder: 'اسألني عن أي شيء...',
            greeting: 'مرحبًا! أنا مساعدك الذكي. كيف يمكنني مساعدتك بخصوص Flix-IPTV؟'
        },
        
        // التذييل
        footer: {
            description: 'خدمة IPTV متميزة مع تغطية عالمية ودعم متعدد اللغات.',
            links: 'روابط سريعة',
            packages: 'الباقات',
            activation: 'التفعيل',
            faq: 'الأسئلة الشائعة',
            terms: 'شروط الخدمة',
            privacy: 'سياسة الخصوصية',
            contact: 'اتصل بنا',
            newsletter: 'النشرة البريدية',
            newsletterDesc: 'اشترك للحصول على التحديثات والعروض',
            emailPlaceholder: 'بريدك الإلكتروني',
            subscribe: 'اشترك',
            copyright: '© 2024 Flix-IPTV. جميع الحقوق محفوظة.'
        },
        
        // صفحات النجاح والإلغاء
        success: {
            title: 'تم الدفع بنجاح!',
            message: 'شكرًا لشرائك. تم تفعيل اشتراكك.',
            orderId: 'رقم الطلب',
            activationCode: 'كود التفعيل',
            instructions: 'لتفعيل جهازك:',
            step1: '1. أدخل عنوان MAC في قسم التفعيل',
            step2: '2. استخدم كود التفعيل أعلاه',
            step3: '3. اتبع دليل التثبيت الخاص بجهازك',
            support: 'تحتاج مساعدة؟ اتصل بدعمنا المتواصل 24/7.',
            backHome: 'العودة للرئيسية'
        },
        
        cancel: {
            title: 'تم إلغاء الدفع',
            message: 'تم إلغاء دفعتك. لم يتم خصم أي مبلغ من حسابك.',
            reason: 'الأسباب المحتملة:',
            reason1: 'قمت بإلغاء الدفع',
            reason2: 'انتهت صلاحية جلسة الدفع',
            reason3: 'مشكلة تقنية',
            retry: 'إعادة المحاولة',
            backHome: 'العودة للرئيسية'
        }
    },
    
    fr: {
        // التنقل
        nav: {
            home: 'Accueil',
            packages: 'Forfaits',
            activation: 'Activation',
            support: 'Support',
            faq: 'FAQ',
            subscribe: 'S\'abonner Maintenant'
        },
        
        // القسم الرئيسي
        hero: {
            title: 'Service IPTV Premium pour Tous les Appareils',
            description: 'Regardez 400+ chaînes en direct, 12 000+ films et émissions de télévision en plusieurs langues. Sans contrat, annulez à tout moment.',
            channels: 'Chaînes en Direct',
            vod: 'Films & Séries TV',
            support: 'Support Premium',
            countries: 'Pays',
            cta: 'Commencer Maintenant'
        },
        
        // الباقات
        packages: {
            title: 'Choisissez Votre Forfait',
            subtitle: 'Sélectionnez le forfait parfait pour vos besoins de divertissement',
            perDuration: '/ mois',
            select: 'Sélectionner',
            recommended: 'Recommandé',
            features: 'Fonctionnalités'
        },
        
        // التفعيل
        activation: {
            title: 'Activation de l\'Appareil',
            macTitle: 'Entrez Votre Adresse MAC',
            detect: 'Détecter l\'Appareil',
            macHint: 'Format: 00:1A:2B:3C:4D:5E ou 00-1A-2B-3C-4D-5E',
            guidesTitle: 'Guides d\'Installation',
            detected: 'Appareil Détecté',
            mac: 'Adresse MAC',
            type: 'Type d\'Appareil',
            status: 'Statut',
            ready: 'Prêt pour l\'Activation',
            viewGuide: 'Voir le Guide d\'Installation'
        },
        
        // الدفع
        payment: {
            title: 'Terminez Votre Abonnement',
            summary: 'Résumé de la Commande',
            plan: 'Forfait',
            price: 'Prix',
            total: 'Total',
            paymentDetails: 'Détails du Paiement',
            email: 'Adresse Email',
            method: 'Méthode de Paiement',
            creditCard: 'Carte de Crédit/Débit',
            crypto: 'Cryptomonnaie',
            selectCrypto: 'Sélectionnez la Cryptomonnaie',
            proceed: 'Procéder au Paiement',
            secure: 'Sécurisé 256-bit SSL',
            encrypted: 'Paiement Crypté'
        },
        
        // الأسئلة الشائعة
        faq: {
            title: 'Questions Fréquemment Posées',
            q1: 'Quels appareils sont pris en charge ?',
            a1: 'Nous prenons en charge tous les appareils principaux : Android, iOS, Smart TVs, Fire Stick, MAG Box, Windows et Mac. Des guides d\'installation détaillés sont disponibles.',
            q2: 'Comment activer mon service ?',
            a2: 'Après paiement, entrez l\'adresse MAC de votre appareil dans la section d\'activation. Vous recevrez immédiatement votre code d\'activation.',
            q3: 'Quelles méthodes de paiement acceptez-vous ?',
            a3: 'Nous acceptons les cartes de crédit/débit (Visa, MasterCard) et les principales cryptomonnaies (Bitcoin, Ethereum, USDT) via une passerelle de paiement sécurisée.',
            q4: 'Y a-t-il un essai gratuit disponible ?',
            a4: 'Nous proposons un essai de 24 heures pour 1 $ pour garantir la qualité du service. Ce montant sera déduit de votre premier abonnement.',
            q5: 'Puis-je utiliser le service sur plusieurs appareils ?',
            a5: 'Le forfait premium prend en charge 2 connexions simultanées. Les autres forfaits prennent en charge 1 connexion.',
            q6: 'Comment obtenir du support ?',
            a6: 'Nous offrons un support 24/7 via Telegram, WhatsApp, Messenger et email.'
        },
        
        // مساعد الذكاء الاصطناعي
        ai: {
            title: 'Assistant IA',
            placeholder: 'Demandez-moi n\'importe quoi...',
            greeting: 'Bonjour ! Je suis votre assistant IA. Comment puis-je vous aider avec Flix-IPTV ?'
        },
        
        // التذييل
        footer: {
            description: 'Service IPTV premium avec couverture mondiale et support multilingue.',
            links: 'Liens Rapides',
            packages: 'Forfaits',
            activation: 'Activation',
            faq: 'FAQ',
            terms: 'Conditions d\'Utilisation',
            privacy: 'Politique de Confidentialité',
            contact: 'Contactez-Nous',
            newsletter: 'Newsletter',
            newsletterDesc: 'Abonnez-vous pour les mises à jour et offres',
            emailPlaceholder: 'Votre email',
            subscribe: 'S\'abonner',
            copyright: '© 2024 Flix-IPTV. Tous droits réservés.'
        },
        
        // صفحات النجاح والإلغاء
        success: {
            title: 'Paiement Réussi !',
            message: 'Merci pour votre achat. Votre abonnement a été activé.',
            orderId: 'Numéro de Commande',
            activationCode: 'Code d\'Activation',
            instructions: 'Pour activer votre appareil :',
            step1: '1. Entrez votre adresse MAC dans la section d\'activation',
            step2: '2. Utilisez le code d\'activation ci-dessus',
            step3: '3. Suivez le guide d\'installation spécifique à l\'appareil',
            support: 'Besoin d\'aide ? Contactez notre support 24/7.',
            backHome: 'Retour à l\'Accueil'
        },
        
        cancel: {
            title: 'Paiement Annulé',
            message: 'Votre paiement a été annulé. Aucun montant n\'a été débité de votre compte.',
            reason: 'Raisons possibles :',
            reason1: 'Vous avez annulé le paiement',
            reason2: 'La session de paiement a expiré',
            reason3: 'Problème technique',
            retry: 'Réessayer le Paiement',
            backHome: 'Retour à l\'Accueil'
        }
    },
    
    es: {
        // التنقل
        nav: {
            home: 'Inicio',
            packages: 'Planes',
            activation: 'Activación',
            support: 'Soporte',
            faq: 'Preguntas Frecuentes',
            subscribe: 'Suscribirse Ahora'
        },
        
        // القسم الرئيسي
        hero: {
            title: 'Servicio IPTV Premium para Todos los Dispositivos',
            description: 'Mira 400+ canales en vivo, 12,000+ películas y programas de TV en múltiples idiomas. Sin contratos, cancela en cualquier momento.',
            channels: 'Canales en Vivo',
            vod: 'Películas y Series',
            support: 'Soporte Premium',
            countries: 'Países',
            cta: 'Comenzar Ahora'
        },
        
        // الباقات
        packages: {
            title: 'Elige Tu Plan',
            subtitle: 'Selecciona el plan perfecto para tus necesidades de entretenimiento',
            perDuration: '/ mes',
            select: 'Seleccionar Plan',
            recommended: 'Recomendado',
            features: 'Características'
        },
        
        // التفعيل
        activation: {
            title: 'Activación del Dispositivo',
            macTitle: 'Ingresa tu Dirección MAC',
            detect: 'Detectar Dispositivo',
            macHint: 'Formato: 00:1A:2B:3C:4D:5E o 00-1A-2B-3C-4D-5E',
            guidesTitle: 'Guías de Instalación',
            detected: 'Dispositivo Detectado',
            mac: 'Dirección MAC',
            type: 'Tipo de Dispositivo',
            status: 'Estado',
            ready: 'Listo para Activación',
            viewGuide: 'Ver Guía de Instalación'
        },
        
        // الدفع
        payment: {
            title: 'Completa Tu Suscripción',
            summary: 'Resumen del Pedido',
            plan: 'Plan',
            price: 'Precio',
            total: 'Total',
            paymentDetails: 'Detalles del Pago',
            email: 'Correo Electrónico',
            method: 'Método de Pago',
            creditCard: 'Tarjeta de Crédito/Débito',
            crypto: 'Criptomoneda',
            selectCrypto: 'Selecciona Criptomoneda',
            proceed: 'Proceder al Pago',
            secure: 'Seguro 256-bit SSL',
            encrypted: 'Pago Encriptado'
        },
        
        // الأسئلة الشائعة
        faq: {
            title: 'Preguntas Frecuentes',
            q1: '¿Qué dispositivos son compatibles?',
            a1: 'Soportamos todos los dispositivos principales: Android, iOS, Smart TVs, Fire Stick, MAG Box, Windows y Mac. Hay guías de instalación detalladas disponibles.',
            q2: '¿Cómo activo mi servicio?',
            a2: 'Después del pago, ingresa la dirección MAC de tu dispositivo en la sección de activación. Recibirás tu código de activación inmediatamente.',
            q3: '¿Qué métodos de pago aceptan?',
            a3: 'Aceptamos tarjetas de crédito/débito (Visa, MasterCard) y las principales criptomonedas (Bitcoin, Ethereum, USDT) a través de una pasarela de pago segura.',
            q4: '¿Hay una prueba gratuita disponible?',
            a4: 'Ofrecemos una prueba de 24 horas por $1 para garantizar la calidad del servicio. Esta cantidad se deducirá de tu primera suscripción.',
            q5: '¿Puedo usar el servicio en múltiples dispositivos?',
            a5: 'El plan premium soporta 2 conexiones simultáneas. Otros planes soportan 1 conexión.',
            q6: '¿Cómo obtengo soporte?',
            a6: 'Ofrecemos soporte 24/7 a través de Telegram, WhatsApp, Messenger y correo electrónico.'
        },
        
        // مساعد الذكاء الاصطناعي
        ai: {
            title: 'Asistente IA',
            placeholder: 'Pregúntame lo que quieras...',
            greeting: '¡Hola! Soy tu asistente de IA. ¿Cómo puedo ayudarte con Flix-IPTV?'
        },
        
        // التذييل
        footer: {
            description: 'Servicio IPTV premium con cobertura mundial y soporte multilingüe.',
            links: 'Enlaces Rápidos',
            packages: 'Planes',
            activation: 'Activación',
            faq: 'Preguntas Frecuentes',
            terms: 'Términos del Servicio',
            privacy: 'Política de Privacidad',
            contact: 'Contáctanos',
            newsletter: 'Boletín',
            newsletterDesc: 'Suscríbete para actualizaciones y ofertas',
            emailPlaceholder: 'Tu correo',
            subscribe: 'Suscribirse',
            copyright: '© 2024 Flix-IPTV. Todos los derechos reservados.'
        },
        
        // صفحات النجاح والإلغاء
        success: {
            title: '¡Pago Exitoso!',
            message: 'Gracias por tu compra. Tu suscripción ha sido activada.',
            orderId: 'ID del Pedido',
            activationCode: 'Código de Activación',
            instructions: 'Para activar tu dispositivo:',
            step1: '1. Ingresa tu dirección MAC en la sección de activación',
            step2: '2. Usa el código de activación de arriba',
            step3: '3. Sigue la guía de instalación específica del dispositivo',
            support: '¿Necesitas ayuda? Contacta a nuestro soporte 24/7.',
            backHome: 'Volver al Inicio'
        },
        
        cancel: {
            title: 'Pago Cancelado',
            message: 'Tu pago ha sido cancelado. No se ha cargado ningún monto a tu cuenta.',
            reason: 'Posibles razones:',
            reason1: 'Cancelaste el pago',
            reason2: 'La sesión de pago expiró',
            reason3: 'Problema técnico',
            retry: 'Reintentar Pago',
            backHome: 'Volver al Inicio'
        }
    },
    
    he: {
        // التنقل
        nav: {
            home: 'דף הבית',
            packages: 'חבילות',
            activation: 'הפעלה',
            support: 'תמיכה',
            faq: 'שאלות נפוצות',
            subscribe: 'הירשם עכשיו'
        },
        
        // القسم الرئيسي
        hero: {
            title: 'שירות IPTV פרימיום לכל המכשירים',
            description: 'צפה ב-400+ ערוצים חיים, 12,000+ סרטים ותוכניות טלוויזיה במספר שפות. ללא חוזים, ניתן לבטל בכל עת.',
            channels: 'ערוצים חיים',
            vod: 'סרטים ותוכניות טלוויזיה',
            support: 'תמיכה פרימיום',
            countries: 'מדינות',
            cta: 'התחל עכשיו'
        },
        
        // الباقات
        packages: {
            title: 'בחר את התוכנית שלך',
            subtitle: 'בחר את התוכנית המושלמת לצרכי הבידור שלך',
            perDuration: '/ חודש',
            select: 'בחר תוכנית',
            recommended: 'מומלץ',
            features: 'תכונות'
        },
        
        // التفعيل
        activation: {
            title: 'הפעלת המכשיר',
            macTitle: 'הזן את כתובת ה-MAC של המכשיר שלך',
            detect: 'זהה מכשיר',
            macHint: 'פורמט: 00:1A:2B:3C:4D:5E או 00-1A-2B-3C-4D-5E',
            guidesTitle: 'מדריכי התקנה',
            detected: 'מכשיר אותר',
            mac: 'כתובת MAC',
            type: 'סוג המכשיר',
            status: 'סטטוס',
            ready: 'מוכן להפעלה',
            viewGuide: 'הצג מדריך התקנה'
        },
        
        // الدفع
        payment: {
            title: 'השלם את המנוי שלך',
            summary: 'סיכום הזמנה',
            plan: 'תוכנית',
            price: 'מחיר',
            total: 'סה"כ',
            paymentDetails: 'פרטי תשלום',
            email: 'כתובת אימייל',
            method: 'שיטת תשלום',
            creditCard: 'כרטיס אשראי/חיוב',
            crypto: 'מטבע קריפטו',
            selectCrypto: 'בחר מטבע קריפטו',
            proceed: 'המשך לתשלום',
            secure: 'מוגן ב-256-bit SSL',
            encrypted: 'תשלום מוצפן'
        },
        
        // الأسئلة الشائعة
        faq: {
            title: 'שאלות נפוצות',
            q1: 'אילו מכשירים נתמכים?',
            a1: 'אנו תומכים בכל המכשירים העיקריים: אנדרואיד, iOS, טלוויזיות חכמות, פיירסטיק, קופסאות MAG, Windows ו-Mac. מדריכי התקנה מפורטים זמינים.',
            q2: 'כיצד להפעיל את השירות שלי?',
            a2: 'לאחר התשלום, הזן את כתובת ה-MAC של המכשיר שלך בחלק ההפעלה. תקבל את קוד ההפעלה שלך מיידית.',
            q3: 'אילו שיטות תשלום אתם מקבלים?',
            a3: 'אנו מקבלים כרטיסי אשראי/חיוב (ויזה, מאסטרקארד) ומטבעות קריפטו עיקריים (ביטקוין, אתריום, USDT) דרך שער תשלום מאובטח.',
            q4: 'האם קיים ניסיון חינם?',
            a4: 'אנו מציעים ניסיון של 24 שעות תמורת 1 דולר כדי להבטיח את איכות השירות. סכום זה ינוכה מהמנוי הראשון שלך.',
            q5: 'האם אוכל להשתמש בשירות במספר מכשירים?',
            a5: 'התוכנית הפרימיום תומכת ב-2 חיבורים בו-זמנית. תוכניות אחרות תומכות בחיבור אחד.',
            q6: 'כיצד אוכל לקבל תמיכה?',
            a6: 'אנו מספקים תמיכה 24/7 דרך טלגרם, וואטסאפ, מסנג\'ר ואימייל.'
        },
        
        // مساعد الذكاء الاصطناعي
        ai: {
            title: 'עוזר בינה מלאכותית',
            placeholder: 'שאל אותי כל דבר...',
            greeting: 'שלום! אני העוזר הבינה המלאכותית שלך. כיצד אוכל לעזור לך עם Flix-IPTV?'
        },
        
        // التذييل
        footer: {
            description: 'שירות IPTV פרימיום עם כיסוי עולמי ותמיכה רב-לשונית.',
            links: 'קישורים מהירים',
            packages: 'חבילות',
            activation: 'הפעלה',
            faq: 'שאלות נפוצות',
            terms: 'תנאי שימוש',
            privacy: 'מדיניות פרטיות',
            contact: 'צור קשר',
            newsletter: 'רשימת תפוצה',
            newsletterDesc: 'הירשם לעדכונים והצעות',
            emailPlaceholder: 'האימייל שלך',
            subscribe: 'הירשם',
            copyright: '© 2024 Flix-IPTV. כל הזכויות שמורות.'
        },
        
        // صفحات النجاح والإلغاء
        success: {
            title: 'התשלום הצליח!',
            message: 'תודה על הרכישה שלך. המנוי שלך הופעל.',
            orderId: 'מספר הזמנה',
            activationCode: 'קוד הפעלה',
            instructions: 'להפעלת המכשיר שלך:',
            step1: '1. הזן את כתובת ה-MAC שלך בחלק ההפעלה',
            step2: '2. השתמש בקוד ההפעלה שלעיל',
            step3: '3. עקוב אחר מדריך ההתקנה הספציפי למכשיר',
            support: 'צריך עזרה? פנה לתמיכה שלנו 24/7.',
            backHome: 'חזרה לדף הבית'
        },
        
        cancel: {
            title: 'התשלום בוטל',
            message: 'התשלום שלך בוטל. לא חויבת שום סכום לחשבונך.',
            reason: 'סיבות אפשריות:',
            reason1: 'ביטלת את התשלום',
            reason2: 'פג תוקף ההפעלה של התשלום',
            reason3: 'בעיה טכנית',
            retry: 'נסה שוב',
            backHome: 'חזרה לדף הבית'
        }
    }
};

// تصدير الترجمات
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TRANSLATIONS;
} else {
    window.TRANSLATIONS = TRANSLATIONS;
}