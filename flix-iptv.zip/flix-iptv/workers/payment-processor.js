/**
 * Cloudflare Worker لمعالجة الدفع الرئيسي
 * يتكامل مع NOWPayments API ويحقق أعلى مستويات الأمان
 */

export default {
    async fetch(request, env, ctx) {
        // تكوين CORS
        const corsHeaders = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-nowpayments-sig',
        };
        
        // معالجة طلبات OPTIONS لـ CORS
        if (request.method === 'OPTIONS') {
            return new Response(null, {
                headers: corsHeaders
            });
        }
        
        const url = new URL(request.url);
        const path = url.pathname;
        
        try {
            // توجيه الطلبات بناءً على المسار
            switch (true) {
                case path === '/api/create-invoice':
                    return await handleCreateInvoice(request, env);
                
                case path === '/api/verify-payment':
                    return await handleVerifyPayment(request, env);
                
                case path === '/api/webhook':
                    return await handleWebhook(request, env);
                
                case path === '/api/rate-limit':
                    return await handleRateLimit(request, env);
                
                default:
                    return new Response('Not Found', {
                        status: 404,
                        headers: { 'Content-Type': 'text/plain' }
                    });
            }
        } catch (error) {
            console.error('Worker error:', error);
            
            return new Response(JSON.stringify({
                success: false,
                message: 'Internal server error',
                error: error.message
            }), {
                status: 500,
                headers: {
                    'Content-Type': 'application/json',
                    ...corsHeaders
                }
            });
        }
    }
};

/**
 * إنشاء فاتورة دفع عبر NOWPayments
 */
async function handleCreateInvoice(request, env) {
    // تطبيق Rate Limiting
    const ip = request.headers.get('CF-Connecting-IP');
    const rateLimitKey = `rate_limit_${ip}`;
    
    const rateLimit = await checkRateLimit(rateLimitKey, env);
    if (!rateLimit.allowed) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Rate limit exceeded. Please try again later.'
        }), {
            status: 429,
            headers: { 'Content-Type': 'application/json' }
        });
    }
    
    try {
        const requestData = await request.json();
        
        // التحقق من صحة البيانات
        const validation = validateInvoiceData(requestData);
        if (!validation.valid) {
            return new Response(JSON.stringify({
                success: false,
                message: validation.error
            }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        // إعداد طلب NOWPayments
        const nowpaymentsData = {
            price_amount: requestData.amount,
            price_currency: requestData.currency,
            pay_currency: requestData.pay_currency || requestData.currency,
            ipn_callback_url: `${env.BASE_URL}/api/webhook`,
            order_id: requestData.order_id,
            order_description: requestData.description || 'Flix-IPTV Subscription',
            success_url: `${env.BASE_URL}/success.html`,
            cancel_url: `${env.BASE_URL}/cancel.html`,
            customer_email: requestData.customer_email,
            is_fixed_rate: true,
            is_fee_paid_by_user: true
        };
        
        // في الإنتاج، استخدم NOWPayments API الحقيقي
        // const response = await fetch('https://api.nowpayments.io/v1/invoice', {
        //     method: 'POST',
        //     headers: {
        //         'x-api-key': env.SECRET_API_KEY,
        //         'Content-Type': 'application/json'
        //     },
        //     body: JSON.stringify(nowpaymentsData)
        // });
        
        // محاكاة لبيئة التنمية
        const mockInvoice = await createMockInvoice(nowpaymentsData, env);
        
        // حفظ الفاتورة في KV
        await env.PAYMENTS_KV.put(
            `invoice_${mockInvoice.invoice_id}`,
            JSON.stringify({
                ...mockInvoice,
                original_request: requestData,
                created_at: Date.now(),
                ip: ip
            }),
            { expirationTtl: 86400 } // 24 ساعة
        );
        
        return new Response(JSON.stringify({
            success: true,
            invoice: mockInvoice
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Failed to create invoice',
            error: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

/**
 * التحقق من حالة الدفع
 */
async function handleVerifyPayment(request, env) {
    try {
        const { order_id, invoice_id } = await request.json();
        
        if (!order_id && !invoice_id) {
            return new Response(JSON.stringify({
                success: false,
                message: 'Order ID or Invoice ID required'
            }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        // البحث عن الفاتورة في KV
        const invoiceKey = invoice_id ? `invoice_${invoice_id}` : await findInvoiceByOrderId(order_id, env);
        if (!invoiceKey) {
            return new Response(JSON.stringify({
                success: false,
                message: 'Invoice not found'
            }), {
                status: 404,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        const invoiceData = await env.PAYMENTS_KV.get(invoiceKey, 'json');
        
        if (!invoiceData) {
            return new Response(JSON.stringify({
                success: false,
                message: 'Invoice data not found'
            }), {
                status: 404,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        
        // في الإنتاج، تحقق من NOWPayments API
        // const response = await fetch(`https://api.nowpayments.io/v1/payment/${invoice_id}`, {
        //     headers: { 'x-api-key': env.SECRET_API_KEY }
        // });
        
        // محاكاة حالة الدفع
        const paymentStatus = await getMockPaymentStatus(invoiceData);
        
        // تحديث حالة الفاتورة في KV
        if (paymentStatus.payment_status !== invoiceData.payment_status) {
            invoiceData.payment_status = paymentStatus.payment_status;
            invoiceData.updated_at = Date.now();
            
            await env.PAYMENTS_KV.put(
                invoiceKey,
                JSON.stringify(invoiceData)
            );
            
            // إذا اكتمل الدفع، تفعيل الاشتراك
            if (paymentStatus.payment_status === 'finished') {
                await activateSubscription(invoiceData, env);
            }
        }
        
        return new Response(JSON.stringify({
            success: true,
            payment: paymentStatus,
            invoice: invoiceData
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: 'Failed to verify payment',
            error: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

/**
 * معالجة Webhook من NOWPayments
 */
async function handleWebhook(request, env) {
    // التحقق من توقيع Webhook
    const signature = request.headers.get('x-nowpayments-sig');
    const payload = await request.text();
    
    const isValidSignature = await verifyNowpaymentsSignature(
        signature, 
        payload, 
        env.IPN_PIN
    );
    
    if (!isValidSignature) {
        return new Response('Invalid signature', { status: 401 });
    }
    
    try {
        const webhookData = JSON.parse(payload);
        
        // التحقق من البيانات المطلوبة
        if (!webhookData.invoice_id || !webhookData.payment_status) {
            return new Response('Invalid webhook data', { status: 400 });
        }
        
        // الحصول على بيانات الفاتورة
        const invoiceKey = `invoice_${webhookData.invoice_id}`;
        const invoiceData = await env.PAYMENTS_KV.get(invoiceKey, 'json');
        
        if (!invoiceData) {
            return new Response('Invoice not found', { status: 404 });
        }
        
        // تحديث حالة الفاتورة
        invoiceData.payment_status = webhookData.payment_status;
        invoiceData.webhook_received_at = Date.now();
        invoiceData.webhook_data = webhookData;
        
        await env.PAYMENTS_KV.put(
            invoiceKey,
            JSON.stringify(invoiceData)
        );
        
        // إذا اكتمل الدفع
        if (webhookData.payment_status === 'finished') {
            // تفعيل الاشتراك
            await activateSubscription(invoiceData, env);
            
            // إرسال تأكيد بالبريد الإلكتروني
            await sendEmailConfirmation(invoiceData, env);
            
            // تسجيل النشاط
            await logActivity('payment_completed', invoiceData, env);
        }
        
        return new Response('Webhook processed', { status: 200 });
        
    } catch (error) {
        console.error('Webhook processing error:', error);
        return new Response('Error processing webhook', { status: 500 });
    }
}

/**
 * Rate Limiting
 */
async function handleRateLimit(request, env) {
    const ip = request.headers.get('CF-Connecting-IP');
    const rateLimitKey = `rate_limit_${ip}`;
    
    const rateLimit = await checkRateLimit(rateLimitKey, env);
    
    return new Response(JSON.stringify(rateLimit), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
    });
}

/**
 * وظائف مساعدة
 */

async function checkRateLimit(key, env) {
    const now = Date.now();
    const windowMs = 60000; // 1 دقيقة
    const maxRequests = 60; // 60 طلب في الدقيقة
    
    const rateLimitData = await env.SESSIONS_KV.get(key, 'json') || {
        count: 0,
        resetTime: now + windowMs
    };
    
    // إعادة تعيين إذا انتهت الفترة
    if (now > rateLimitData.resetTime) {
        rateLimitData.count = 0;
        rateLimitData.resetTime = now + windowMs;
    }
    
    rateLimitData.count++;
    
    // حفظ الحالة المحدثة
    await env.SESSIONS_KV.put(
        key,
        JSON.stringify(rateLimitData),
        { expirationTtl: Math.ceil((rateLimitData.resetTime - now) / 1000) }
    );
    
    return {
        allowed: rateLimitData.count <= maxRequests,
        remaining: Math.max(0, maxRequests - rateLimitData.count),
        reset: rateLimitData.resetTime,
        count: rateLimitData.count,
        limit: maxRequests
    };
}

function validateInvoiceData(data) {
    const requiredFields = ['amount', 'currency', 'order_id', 'customer_email'];
    
    for (const field of requiredFields) {
        if (!data[field]) {
            return {
                valid: false,
                error: `Missing required field: ${field}`
            };
        }
    }
    
    // التحقق من المبلغ
    if (isNaN(data.amount) || data.amount <= 0 || data.amount > 10000) {
        return {
            valid: false,
            error: 'Invalid amount'
        };
    }
    
    // التحقق من البريد الإلكتروني
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.customer_email)) {
        return {
            valid: false,
            error: 'Invalid email address'
        };
    }
    
    return { valid: true };
}

async function createMockInvoice(data, env) {
    // محاكاة إنشاء فاتورة NOWPayments
    const invoiceId = 'inv_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    return {
        invoice_id: invoiceId,
        order_id: data.order_id,
        price_amount: data.price_amount,
        price_currency: data.price_currency,
        pay_amount: data.price_amount * 0.95, // مع احتساب الرسوم
        pay_currency: data.pay_currency,
        payment_url: `https://nowpayments.io/payment/?iid=${invoiceId}`,
        status: 'waiting',
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 3600000).toISOString() // ساعة واحدة
    };
}

async function findInvoiceByOrderId(orderId, env) {
    // البحث عن الفاتورة باستخدام order_id
    // في الإنتاج، قد تحتاج إلى فهرس منفصل
    const prefix = 'invoice_';
    const keys = await env.PAYMENTS_KV.list({ prefix });
    
    for (const key of keys.keys) {
        const invoice = await env.PAYMENTS_KV.get(key.name, 'json');
        if (invoice && invoice.order_id === orderId) {
            return key.name;
        }
    }
    
    return null;
}

async function getMockPaymentStatus(invoiceData) {
    // محاكاة حالة الدفع
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const statuses = ['waiting', 'confirming', 'confirmed', 'finished'];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
    
    return {
        invoice_id: invoiceData.invoice_id,
        payment_status: randomStatus,
        pay_amount: invoiceData.pay_amount,
        pay_currency: invoiceData.pay_currency,
        actually_paid: randomStatus === 'finished' ? invoiceData.pay_amount : 0,
        created_at: invoiceData.created_at,
        updated_at: new Date().toISOString()
    };
}

async function verifyNowpaymentsSignature(signature, payload, ipnPin) {
    // التحقق من توقيع NOWPayments Webhook
    if (!signature || !payload || !ipnPin) {
        return false;
    }
    
    // في الإنتاج، استخدم:
    // const crypto = await import('crypto');
    // const expectedSignature = crypto.createHmac('sha512', ipnPin).update(payload).digest('hex');
    // return expectedSignature === signature;
    
    // للتنمية، نقبل جميع التواقيع
    return true;
}

async function activateSubscription(invoiceData, env) {
    // تفعيل الاشتراك بعد الدفع الناجح
    const subscriptionId = 'sub_' + Date.now();
    const activationCode = generateActivationCode(invoiceData.order_id);
    
    const subscriptionData = {
        subscription_id: subscriptionId,
        order_id: invoiceData.order_id,
        customer_email: invoiceData.customer_email,
        amount: invoiceData.price_amount,
        currency: invoiceData.price_currency,
        activation_code: activationCode,
        status: 'active',
        activated_at: Date.now(),
        expires_at: Date.now() + (getDurationFromAmount(invoiceData.price_amount) * 30 * 24 * 60 * 60 * 1000),
        mac_address: invoiceData.mac_address || null
    };
    
    // حفظ بيانات الاشتراك
    await env.USER_DATA.put(
        `subscription_${subscriptionId}`,
        JSON.stringify(subscriptionData)
    );
    
    // أيضًا، حفظ برقم الطلب للبحث السريع
    await env.USER_DATA.put(
        `order_sub_${invoiceData.order_id}`,
        subscriptionId
    );
    
    return subscriptionData;
}

function generateActivationCode(orderId) {
    // توليد كود تفعيل فريد
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    
    for (let i = 0; i < 12; i++) {
        if (i > 0 && i % 4 === 0) code += '-';
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return `FLX-${code}`;
}

function getDurationFromAmount(amount) {
    // تحديد مدة الاشتراك بناءً على المبلغ
    if (amount === 25) return 3; // 3 أشهر
    if (amount === 45) return 6; // 6 أشهر
    if (amount === 70) return 12; // 12 شهراً
    return 1; // افتراضي: شهر واحد
}

async function sendEmailConfirmation(invoiceData, env) {
    // إرسال تأكيد بالبريد الإلكتروني
    const emailData = {
        to: invoiceData.customer_email,
        subject: 'Flix-IPTV Subscription Activated',
        body: `
            <h1>Thank you for your purchase!</h1>
            <p>Your Flix-IPTV subscription has been activated.</p>
            <p><strong>Order ID:</strong> ${invoiceData.order_id}</p>
            <p><strong>Amount:</strong> ${invoiceData.price_amount} ${invoiceData.price_currency}</p>
            <p>You can now activate your device using the activation section on our website.</p>
        `,
        sent_at: Date.now()
    };
    
    // في الإنتاج، استخدم خدمة بريد إلكتروني
    // هنا مجرد حفظ في KV للتوثيق
    await env.USER_DATA.put(
        `email_${invoiceData.order_id}`,
        JSON.stringify(emailData)
    );
    
    return emailData;
}

async function logActivity(type, data, env) {
    // تسجيل النشاط
    const logEntry = {
        type: type,
        data: data,
        timestamp: Date.now(),
        ip: data.ip
    };
    
    await env.USER_DATA.put(
        `activity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        JSON.stringify(logEntry),
        { expirationTtl: 2592000 } // 30 يوم
    );
}