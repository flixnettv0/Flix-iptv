/**
 * نظام إدارة اللغات لـ Flix-IPTV
 * يدعم التبديل الفوري بين 5 لغات مع الحفاظ على حالة التطبيق
 */

class LanguageManager {
    constructor() {
        this.currentLang = 'en';
        this.translations = {};
        this.rtlLanguages = ['ar', 'he'];
        
        this.init();
    }
    
    async init() {
        // تحميل الترجمات
        await this.loadTranslations();
        
        // محاولة اكتشاف اللغة تلقائياً
        this.detectLanguage();
        
        // إعداد مستمع لأزرار التبديل
        this.setupEventListeners();
        
        // تطبيق اللغة الحالية
        this.applyLanguage(this.currentLang);
    }
    
    async loadTranslations() {
        try {
            const response = await fetch('/config/translations.json');
            this.translations = await response.json();
        } catch (error) {
            console.error('Failed to load translations:', error);
            // استخدام الترجمات الافتراضية
            this.translations = await this.getDefaultTranslations();
        }
    }
    
    detectLanguage() {
        // التحقق من التخزين المحلي أولاً
        const savedLang = localStorage.getItem('flix_iptv_language');
        if (savedLang && this.translations[savedLang]) {
            this.currentLang = savedLang;
            return;
        }
        
        // اكتشاف لغة المتصفح
        const browserLang = navigator.language.substring(0, 2);
        if (this.translations[browserLang]) {
            this.currentLang = browserLang;
        }
        
        // للعربية والعبرية، نفحص أيضاً اللغة المعتمدة
        if (this.rtlLanguages.includes(browserLang) && this.translations[browserLang]) {
            this.currentLang = browserLang;
        }
    }
    
    setupEventListeners() {
        // مستمع لمبدل اللغة
        const langSwitcher = document.getElementById('language-switcher');
        if (langSwitcher) {
            langSwitcher.value = this.currentLang;
            langSwitcher.addEventListener('change', (e) => {
                this.switchLanguage(e.target.value);
            });
        }
        
        // مستمعات لأزرار التبديل السريع (إذا وجدت)
        document.querySelectorAll('.lang-switch-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const lang = e.target.dataset.lang;
                if (lang) {
                    this.switchLanguage(lang);
                }
            });
        });
    }
    
    switchLanguage(langCode) {
        if (!this.translations[langCode]) {
            console.error(`Language ${langCode} not found`);
            return;
        }
        
        this.currentLang = langCode;
        localStorage.setItem('flix_iptv_language', langCode);
        this.applyLanguage(langCode);
        
        // تحديث واجهة مبدل اللغة
        const langSwitcher = document.getElementById('language-switcher');
        if (langSwitcher) {
            langSwitcher.value = langCode;
        }
        
        // إشعار بتغيير اللغة
        this.showLanguageNotification(langCode);
    }
    
    applyLanguage(langCode) {
        // تطبيق اتجاه النص
        this.applyTextDirection(langCode);
        
        // تطبيق الترجمات على جميع العناصر
        this.translatePage(langCode);
        
        // تحديث أي بيانات ديناميكية (مثل الأسعار إذا كانت مختلفة)
        this.updateDynamicContent(langCode);
    }
    
    applyTextDirection(langCode) {
        const htmlElement = document.documentElement;
        
        if (this.rtlLanguages.includes(langCode)) {
            htmlElement.dir = 'rtl';
            htmlElement.lang = langCode;
            htmlElement.classList.add('rtl');
        } else {
            htmlElement.dir = 'ltr';
            htmlElement.lang = langCode;
            htmlElement.classList.remove('rtl');
        }
    }
    
    translatePage(langCode) {
        const langData = this.translations[langCode];
        if (!langData) return;
        
        // ترجمة العناصر مع data-i18n
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.getTranslation(langData, key);
            if (translation) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translation;
                } else {
                    element.textContent = translation;
                }
            }
        });
        
        // ترجمة عناصر الـ title
        document.querySelectorAll('[data-i18n-title]').forEach(element => {
            const key = element.getAttribute('data-i18n-title');
            const translation = this.getTranslation(langData, key);
            if (translation) {
                element.title = translation;
            }
        });
        
        // تحديث خاصية lang للصفحة
        document.documentElement.lang = langCode;
    }
    
    getTranslation(langData, key) {
        const keys = key.split('.');
        let value = langData;
        
        for (const k of keys) {
            if (value && typeof value === 'object' && k in value) {
                value = value[k];
            } else {
                return null;
            }
        }
        
        return typeof value === 'string' ? value : null;
    }
    
    updateDynamicContent(langCode) {
        // تحديث عرض الباقات إذا كانت الأسعار مختلفة حسب المنطقة
        const priceConfig = window.PRICING_CONFIG;
        if (priceConfig && priceConfig.packages) {
            this.updatePackageDisplay(langCode, priceConfig);
        }
        
        // تحديث أي محتوى آخر ديناميكي
        this.updateFAQDisplay(langCode);
    }
    
    updatePackageDisplay(langCode, priceConfig) {
        const packagesContainer = document.getElementById('packages-container');
        if (!packagesContainer) return;
        
        // إذا كان هناك عرض حزم مخصص للغة، قم بتحديثه هنا
        // هذا مثال بسيط لتحديث أسماء الباقات فقط
        const packageElements = packagesContainer.querySelectorAll('.package-card');
        packageElements.forEach((card, index) => {
            const packageData = priceConfig.packages[index];
            if (packageData && packageData.name[langCode]) {
                const titleElement = card.querySelector('.package-title');
                if (titleElement) {
                    titleElement.textContent = packageData.name[langCode];
                }
            }
        });
    }
    
    updateFAQDisplay(langCode) {
        // تحديث الأسئلة الشائعة إذا كانت هناك بيانات ديناميكية
        // يمكن تخصيص هذا حسب الحاجة
    }
    
    showLanguageNotification(langCode) {
        // إظهار إشعار مؤقت بتغيير اللغة
        const notification = document.createElement('div');
        notification.className = 'language-notification';
        
        const langNames = {
            'en': 'English',
            'ar': 'العربية',
            'fr': 'Français',
            'es': 'Español',
            'he': 'עברית'
        };
        
        notification.textContent = `Language changed to ${langNames[langCode]}`;
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #4f46e5;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 2000);
    }
    
    async getDefaultTranslations() {
        // ترجمات افتراضية في حالة فشل تحميل ملف الترجمات
        return {
            'en': {
                'nav': {
                    'home': 'Home',
                    'packages': 'Packages',
                    'activation': 'Activation',
                    'support': 'Support',
                    'faq': 'FAQ',
                    'subscribe': 'Subscribe Now'
                },
                'hero': {
                    'title': 'Premium IPTV Service for All Devices',
                    'description': 'Watch 400+ live channels, 12,000+ movies and TV shows in multiple languages.',
                    'channels': 'Live Channels',
                    'vod': 'Movies & TV Shows',
                    'support': 'Premium Support',
                    'countries': 'Countries',
                    'cta': 'Get Started Now'
                }
                // يمكن إضافة المزيد حسب الحاجة
            },
            'ar': {
                'nav': {
                    'home': 'الرئيسية',
                    'packages': 'الباقات',
                    'activation': 'التفعيل',
                    'support': 'الدعم',
                    'faq': 'الأسئلة الشائعة',
                    'subscribe': 'اشترك الآن'
                },
                'hero': {
                    'title': 'خدمة IPTV متميزة لجميع الأجهزة',
                    'description': 'شاهد أكثر من 400 قناة بث مباشر، 12,000+ فيلم ومسلسل بعدة لغات.',
                    'channels': 'قنوات مباشرة',
                    'vod': 'أفلام ومسلسلات',
                    'support': 'دعم فني متميز',
                    'countries': 'دولة',
                    'cta': 'ابدأ الآن'
                }
            }
        };
    }
    
    // وظيفة مساعدة للحصول على الترجمات الديناميكية
    t(key, defaultValue = '') {
        const langData = this.translations[this.currentLang];
        if (!langData) return defaultValue;
        
        const translation = this.getTranslation(langData, key);
        return translation || defaultValue;
    }
}

// تهيئة مدير اللغة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.languageManager = new LanguageManager();
});

// تصدير للاستخدام في ملفات أخرى
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LanguageManager;
}