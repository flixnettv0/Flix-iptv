/**
 * الملف الرئيسي لجافاسكريبت لـ Flix-IPTV
 * يحتوي على منطق التطبيق الرئيسي وإدارة الحالة
 */

class FlixIPTVApp {
    constructor() {
        this.currentPackage = null;
        this.selectedPaymentMethod = 'card';
        this.deviceType = null;
        this.orderData = null;
        
        this.init();
    }
    
    async init() {
        // انتظار تحميل مدير اللغة
        await this.waitForLanguageManager();
        
        // تهيئة جميع المكونات
        this.initializeComponents();
        this.setupEventListeners();
        this.loadPackages();
        this.setupAIHelper();
        this.setupSupportWidget();
        
        // التحقق من وجود بيانات جلسة سابقة
        this.restoreSession();
        
        console.log('Flix-IPTV App initialized successfully');
    }
    
    async waitForLanguageManager() {
        // انتظار تهيئة مدير اللغة
        return new Promise((resolve) => {
            const checkInterval = setInterval(() => {
                if (window.languageManager) {
                    clearInterval(checkInterval);
                    resolve();
                }
            }, 100);
        });
    }
    
    initializeComponents() {
        // تهيئة مكونات واجهة المستخدم
        this.initializePackageDisplay();
        this.initializePaymentForm();
        this.initializeDeviceDetection();
        this.initializeFAQAccordion();
    }
    
    setupEventListeners() {
        // مستمعات لأزرار الاشتراك
        document.querySelectorAll('#subscribe-btn, #hero-subscribe-btn').forEach(btn => {
            btn.addEventListener('click', () => this.showPaymentSection());
        });
        
        // مستمعات لأزرار الباقات
        document.addEventListener('click', (e) => {
            if (e.target.closest('.package-select-btn')) {
                const packageCard = e.target.closest('.package-card');
                this.selectPackage(packageCard.dataset.packageId);
            }
        });
        
        // مستمع لأزرار اكتشاف الجهاز
        const detectBtn = document.getElementById('detect-device-btn');
        if (detectBtn) {
            detectBtn.addEventListener('click', () => this.detectDevice());
        }
        
        // مستمع لأزرار دليل التثبيت
        document.querySelectorAll('.guide-card').forEach(card => {
            card.addEventListener('click', (e) => {
                this.showInstallationGuide(e.currentTarget.dataset.device);
            });
        });
    }
    
    loadPackages() {
        const packagesContainer = document.getElementById('packages-container');
        if (!packagesContainer) return;
        
        // تحميل بيانات الباقات من التكوين
        const packages = window.PRICING_CONFIG?.packages || this.getDefaultPackages();
        
        packagesContainer.innerHTML = '';
        
        packages.forEach(pkg => {
            const packageElement = this.createPackageElement(pkg);
            packagesContainer.appendChild(packageElement);
        });
        
        // تحديد الباقة الأولى افتراضياً
        if (packages.length > 0) {
            this.selectPackage(packages[0].id);
        }
    }
    
    createPackageElement(pkg) {
        const lang = window.languageManager?.currentLang || 'en';
        
        const packageElement = document.createElement('div');
        packageElement.className = 'package-card';
        packageElement.dataset.packageId = pkg.id;
        
        // تحديد إذا كانت هذه الباقة موصى بها
        const isRecommended = pkg.id === 'standard_6m';
        
        packageElement.innerHTML = `
            ${isRecommended ? '<div class="recommended-badge" data-i18n="packages.recommended">Recommended</div>' : ''}
            <h3 class="package-title">${pkg.name[lang] || pkg.name.en}</h3>
            <div class="package-price">
                <span class="currency">${pkg.currency}</span>
                <span class="amount">${pkg.price.toFixed(2)}</span>
                <span class="duration" data-i18n="packages.perDuration">/ ${pkg.duration} months</span>
            </div>
            <ul class="package-features">
                ${pkg.features.map(feature => `<li>${feature}</li>`).join('')}
            </ul>
            <button class="package-select-btn" data-i18n="packages.select">
                Select Plan
            </button>
        `;
        
        return packageElement;
    }
    
    selectPackage(packageId) {
        // إزالة التحديد من جميع الباقات
        document.querySelectorAll('.package-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // إضافة التحديد للباقة المختارة
        const selectedCard = document.querySelector(`[data-package-id="${packageId}"]`);
        if (selectedCard) {
            selectedCard.classList.add('selected');
            
            // تحديث بيانات الباقة الحالية
            const packages = window.PRICING_CONFIG?.packages || this.getDefaultPackages();
            this.currentPackage = packages.find(p => p.id === packageId);
            
            // تحديث ملخص الطلب في قسم الدفع
            this.updateOrderSummary();
            
            // التمرير إلى قسم الدفع إذا كان مرئياً
            if (document.getElementById('payment').style.display !== 'none') {
                document.getElementById('payment').scrollIntoView({ behavior: 'smooth' });
            }
        }
    }
    
    updateOrderSummary() {
        if (!this.currentPackage) return;
        
        const lang = window.languageManager?.currentLang || 'en';
        
        // تحديث عناصر ملخص الطلب
        const planElement = document.getElementById('selected-plan');
        const priceElement = document.getElementById('selected-price');
        const totalElement = document.getElementById('order-total');
        
        if (planElement) {
            planElement.textContent = this.currentPackage.name[lang] || this.currentPackage.name.en;
        }
        
        if (priceElement) {
            priceElement.textContent = `${this.currentPackage.currency}${this.currentPackage.price.toFixed(2)}`;
        }
        
        if (totalElement) {
            totalElement.textContent = `${this.currentPackage.currency}${this.currentPackage.price.toFixed(2)}`;
        }
    }
    
    showPaymentSection() {
        // إظهار قسم الدفع
        const paymentSection = document.getElementById('payment');
        paymentSection.style.display = 'block';
        
        // إذا لم يتم تحديد باقة، حدد الأولى
        if (!this.currentPackage) {
            const firstPackage = document.querySelector('.package-card');
            if (firstPackage) {
                this.selectPackage(firstPackage.dataset.packageId);
            }
        }
        
        // التمرير إلى قسم الدفع
        paymentSection.scrollIntoView({ behavior: 'smooth' });
    }
    
    initializePaymentForm() {
        const paymentForm = document.getElementById('payment-form');
        if (!paymentForm) return;
        
        // مستمع لتغيير طريقة الدفع
        document.querySelectorAll('input[name="payment-method"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.selectedPaymentMethod = e.target.value;
                this.toggleCryptoCurrencyInput();
            });
        });
        
        // مستمع لإرسال النموذج
        paymentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.processPayment();
        });
    }
    
    toggleCryptoCurrencyInput() {
        const cryptoGroup = document.getElementById('crypto-currency-group');
        if (!cryptoGroup) return;
        
        if (this.selectedPaymentMethod === 'crypto') {
            cryptoGroup.style.display = 'block';
        } else {
            cryptoGroup.style.display = 'none';
        }
    }
    
    async processPayment() {
        // التحقق من صحة النموذج
        if (!this.validatePaymentForm()) {
            return;
        }
        
        // التحقق من أن Cloudflare Turnstile تم التحقق منه
        if (!this.isTurnstileVerified()) {
            this.showError('Please complete the security verification');
            return;
        }
        
        // جمع بيانات الدفع
        const paymentData = this.collectPaymentData();
        
        // عرض حالة التحميل
        this.showLoadingState();
        
        try {
            // إرسال طلب الدفع إلى الخادم
            const response = await fetch('/api/create-payment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(paymentData)
            });
            
            const result = await response.json();
            
            if (result.success && result.paymentUrl) {
                // توجيه المستخدم إلى صفحة الدفع
                window.location.href = result.paymentUrl;
            } else {
                throw new Error(result.message || 'Payment processing failed');
            }
        } catch (error) {
            console.error('Payment error:', error);
            this.showError(`Payment failed: ${error.message}`);
            this.hideLoadingState();
        }
    }
    
    validatePaymentForm() {
        const emailInput = document.getElementById('customer-email');
        const email = emailInput.value.trim();
        
        // التحقق من البريد الإلكتروني
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            this.showError('Please enter a valid email address');
            emailInput.focus();
            return false;
        }
        
        // التحقق من اختيار طريقة الدفع
        if (!this.selectedPaymentMethod) {
            this.showError('Please select a payment method');
            return false;
        }
        
        // إذا كانت العملة المشفرة محددة، تأكد من اختيار عملة
        if (this.selectedPaymentMethod === 'crypto') {
            const cryptoSelect = document.getElementById('crypto-currency');
            if (!cryptoSelect || !cryptoSelect.value) {
                this.showError('Please select a cryptocurrency');
                return false;
            }
        }
        
        return true;
    }
    
    isTurnstileVerified() {
        // هذه وظيفة افتراضية - تحتاج إلى تكامل حقيقي مع Turnstile
        // في التنفيذ الحقيقي، ستتحقق من رمز الاستجابة
        return true;
    }
    
    collectPaymentData() {
        const email = document.getElementById('customer-email').value.trim();
        
        return {
            packageId: this.currentPackage.id,
            packageName: this.currentPackage.name,
            amount: this.currentPackage.price,
            currency: this.currentPackage.currency,
            customerEmail: email,
            paymentMethod: this.selectedPaymentMethod,
            cryptoCurrency: this.selectedPaymentMethod === 'crypto' 
                ? document.getElementById('crypto-currency').value 
                : null,
            timestamp: Date.now(),
            orderId: this.generateOrderId()
        };
    }
    
    generateOrderId() {
        return 'FLX-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9).toUpperCase();
    }
    
    showLoadingState() {
        const submitBtn = document.getElementById('submit-payment');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        }
    }
    
    hideLoadingState() {
        const submitBtn = document.getElementById('submit-payment');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = window.languageManager?.t('payment.proceed', 'Proceed to Payment') || 'Proceed to Payment';
        }
    }
    
    showError(message) {
        // إظهار رسالة خطأ للمستخدم
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ef4444;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(errorDiv);
            }, 300);
        }, 5000);
    }
    
    initializeDeviceDetection() {
        // مستمع لحقل عنوان MAC
        const macInput = document.getElementById('mac-address');
        if (macInput) {
            macInput.addEventListener('input', (e) => {
                this.formatMACAddress(e.target);
            });
        }
    }
    
    formatMACAddress(input) {
        let value = input.value.replace(/[^0-9A-Fa-f]/g, '');
        
        if (value.length > 12) {
            value = value.substring(0, 12);
        }
        
        // تنسيق مع النقطتين
        const formatted = value.match(/.{1,2}/g)?.join(':') || value;
        input.value = formatted;
    }
    
    async detectDevice() {
        const macInput = document.getElementById('mac-address');
        const macAddress = macInput.value.trim();
        
        if (!this.validateMACAddress(macAddress)) {
            this.showError('Please enter a valid MAC address');
            return;
        }
        
        // عرض حالة التحميل
        const detectBtn = document.getElementById('detect-device-btn');
        const originalText = detectBtn.textContent;
        detectBtn.disabled = true;
        detectBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Detecting...';
        
        try {
            // في الواقع، قد يكون هذا استدعاء API للتحقق من الجهاز
            // هنا نستخدم محاكاة بسيطة
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // اكتشاف نوع الجهاز بناءً على بداية عنوان MAC
            const deviceType = this.detectDeviceType(macAddress);
            this.deviceType = deviceType;
            
            // عرض نتيجة الاكتشاف
            this.showDeviceDetectionResult(deviceType, macAddress);
            
        } catch (error) {
            this.showError('Device detection failed. Please try again.');
        } finally {
            detectBtn.disabled = false;
            detectBtn.textContent = originalText;
        }
    }
    
    validateMACAddress(mac) {
        const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
        return macRegex.test(mac);
    }
    
    detectDeviceType(macAddress) {
        // هذه وظيفة مبسطة لاكتشاف نوع الجهاز
        // في التطبيق الحقيقي، قد تستخدم قاعدة بيانات OUI
        
        const ouiPrefix = macAddress.substring(0, 8).toUpperCase();
        
        // قاعدة بيانات مبسطة لبادئات OUI
        const ouiDatabase = {
            '00:1A:2B': 'MAG Box',
            '00:0C:29': 'VMware Virtual',
            '00:50:56': 'VMware Virtual',
            '00:1B:63': 'Android TV',
            '00:1E:06': 'Apple Device',
            '00:25:00': 'Cisco Device',
            'A4:5E:60': 'Amazon Fire TV',
            'F0:99:B6': 'Samsung Smart TV'
        };
        
        for (const [prefix, device] of Object.entries(ouiDatabase)) {
            if (ouiPrefix.startsWith(prefix)) {
                return device;
            }
        }
        
        // إذا لم يتم العثور على تطابق، نعيد نوعاً عاماً
        return 'Generic Streaming Device';
    }
    
    showDeviceDetectionResult(deviceType, macAddress) {
        const resultDiv = document.getElementById('device-result');
        if (!resultDiv) return;
        
        const lang = window.languageManager?.currentLang || 'en';
        
        resultDiv.innerHTML = `
            <div class="device-info-card">
                <h4 data-i18n="activation.detected">Device Detected</h4>
                <div class="device-details">
                    <p><strong data-i18n="activation.mac">MAC Address:</strong> ${macAddress}</p>
                    <p><strong data-i18n="activation.type">Device Type:</strong> ${deviceType}</p>
                    <p><strong data-i18n="activation.status">Status:</strong> <span class="status-ready" data-i18n="activation.ready">Ready for Activation</span></p>
                </div>
                <button class="guide-btn" onclick="flixApp.showInstallationGuide('${this.getDeviceCategory(deviceType)}')" data-i18n="activation.viewGuide">
                    View Installation Guide
                </button>
            </div>
        `;
        
        // تطبيق الترجمات إذا كان مدير اللغة متاحاً
        if (window.languageManager) {
            window.languageManager.applyLanguage(lang);
        }
    }
    
    getDeviceCategory(deviceType) {
        if (deviceType.includes('Android') || deviceType.includes('Fire TV')) {
            return 'android';
        } else if (deviceType.includes('Apple')) {
            return 'ios';
        } else if (deviceType.includes('MAG')) {
            return 'mag';
        } else if (deviceType.includes('TV')) {
            return 'smarttv';
        } else {
            return 'generic';
        }
    }
    
    showInstallationGuide(deviceType) {
        // إظهار دليل التثبيت المناسب للجهاز
        const guides = {
            'android': 'Android devices use the "IPTV Smarters" app from Google Play Store...',
            'ios': 'iOS devices can use "GSE Smart IPTV" from the App Store...',
            'firestick': 'On Fire Stick, install "Downloader" app first, then...',
            'smarttv': 'For Smart TVs, use the built-in "Smart IPTV" app...',
            'mag': 'MAG boxes have automatic portal setup. Enter your MAC address...'
        };
        
        const guideContent = guides[deviceType] || 'Please contact support for device-specific instructions.';
        
        // يمكن إنشاء modal لعرض الدليل
        this.showModal('Installation Guide', guideContent);
    }
    
    showModal(title, content) {
        // إنشاء وتظهر modal
        const modalId = 'guide-modal';
        let modal = document.getElementById(modalId);
        
        if (!modal) {
            modal = document.createElement('div');
            modal.id = modalId;
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>${title}</h3>
                        <button class="modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>${content}</p>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            // إضافة مستمع لإغلاق الزر
            modal.querySelector('.modal-close').addEventListener('click', () => {
                modal.remove();
            });
            
            // إغلاق بالنقر خارج المحتوى
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.remove();
                }
            });
        }
    }
    
    initializeFAQAccordion() {
        document.querySelectorAll('.faq-question').forEach(question => {
            question.addEventListener('click', () => {
                const answer = question.nextElementSibling;
                const icon = question.querySelector('i');
                
                // تبديل فتح/إغلاق السؤال
                if (answer.style.maxHeight) {
                    answer.style.maxHeight = null;
                    icon.style.transform = 'rotate(0deg)';
                } else {
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                    icon.style.transform = 'rotate(180deg)';
                }
            });
        });
    }
    
    setupAIHelper() {
        const aiHelper = document.getElementById('ai-helper');
        const aiClose = document.getElementById('ai-close');
        const aiSend = document.getElementById('ai-send');
        const aiQuery = document.getElementById('ai-query');
        
        if (!aiHelper || !aiClose || !aiSend || !aiQuery) return;
        
        // إظهار/إخفاء مساعد الذكاء الاصطناعي
        const toggleAI = document.createElement('button');
        toggleAI.className = 'ai-toggle-btn';
        toggleAI.innerHTML = '<i class="fas fa-robot"></i>';
        toggleAI.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: #4f46e5;
            color: white;
            border: none;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            cursor: pointer;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
        `;
        document.body.appendChild(toggleAI);
        
        toggleAI.addEventListener('click', () => {
            aiHelper.style.display = aiHelper.style.display === 'none' ? 'block' : 'none';
        });
        
        // إغلاق مساعد الذكاء الاصطناعي
        aiClose.addEventListener('click', () => {
            aiHelper.style.display = 'none';
        });
        
        // إرسال استعلام الذكاء الاصطناعي
        aiSend.addEventListener('click', () => this.processAIQuery());
        aiQuery.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.processAIQuery();
            }
        });
    }
    
    async processAIQuery() {
        const queryInput = document.getElementById('ai-query');
        const chatContainer = document.getElementById('ai-chat');
        const query = queryInput.value.trim();
        
        if (!query) return;
        
        // إضافة استعلام المستخدم إلى الدردشة
        this.addAIMessage(query, 'user');
        queryInput.value = '';
        
        // إضافة رسالة تحميل
        const loadingId = 'ai-loading';
        const loadingDiv = document.createElement('div');
        loadingDiv.id = loadingId;
        loadingDiv.className = 'ai-message ai-loading';
        loadingDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Thinking...';
        chatContainer.appendChild(loadingDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
        
        try {
            // محاكاة استجابة الذكاء الاصطناعي (في الواقع، سيكون هذا استدعاء API)
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // إزالة رسالة التحميل
            const loadingElement = document.getElementById(loadingId);
            if (loadingElement) {
                loadingElement.remove();
            }
            
            // توليد استجابة
            const response = this.generateAIResponse(query);
            this.addAIMessage(response, 'ai');
            
        } catch (error) {
            console.error('AI query failed:', error);
            
            // إزالة رسالة التحميل
            const loadingElement = document.getElementById(loadingId);
            if (loadingElement) {
                loadingElement.remove();
            }
            
            this.addAIMessage('Sorry, I encountered an error. Please try again.', 'ai');
        }
    }
    
    addAIMessage(content, sender) {
        const chatContainer = document.getElementById('ai-chat');
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ai-${sender}`;
        messageDiv.textContent = content;
        chatContainer.appendChild(messageDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
    
    generateAIResponse(query) {
        // قاعدة معرفة مبسطة للذكاء الاصطناعي
        const knowledgeBase = {
            'hello': 'Hello! How can I help you with Flix-IPTV service today?',
            'hi': 'Hi there! Welcome to Flix-IPTV support.',
            'price': 'We have three plans: $25 for 3 months, $45 for 6 months, and $70 for 12 months.',
            'payment': 'We accept credit cards and cryptocurrencies via NOWPayments secure gateway.',
            'device': 'We support Android, iOS, Smart TVs, Fire Stick, MAG Box, and more.',
            'activation': 'After payment, enter your MAC address in the activation section to get your code.',
            'support': 'You can contact us via Telegram, WhatsApp, Messenger, or email.',
            'trial': 'We offer a 24-hour trial for $1, which is deducted from your first subscription.',
            'channels': 'We offer 400+ live channels including sports, movies, news, and entertainment.',
            'vod': 'We have 12,000+ movies and TV shows in our Video on Demand library.',
            'refund': 'We offer refunds within 7 days if the service doesn\'t work on your device.',
            'install': 'Check the activation section for device-specific installation guides.',
            'mac': 'You can find your MAC address in your device\'s network settings.',
            'crypto': 'We accept Bitcoin, Ethereum, and USDT for cryptocurrency payments.'
        };
        
        const queryLower = query.toLowerCase();
        
        // البحث عن أفضل تطابق
        for (const [keyword, response] of Object.entries(knowledgeBase)) {
            if (queryLower.includes(keyword)) {
                return response;
            }
        }
        
        // الرد الافتراضي
        return 'I understand you\'re asking about: "' + query + '". For detailed information, please check our FAQ section or contact our support team.';
    }
    
    setupSupportWidget() {
        const emailSupport = document.getElementById('email-support');
        if (emailSupport) {
            emailSupport.addEventListener('click', () => {
                window.location.href = 'mailto:support@flix-iptv.com?subject=Flix-IPTV Support';
            });
        }
    }
    
    restoreSession() {
        // استعادة الجلسة من localStorage
        const savedPackage = localStorage.getItem('flix_selected_package');
        const savedEmail = localStorage.getItem('flix_customer_email');
        
        if (savedPackage) {
            this.selectPackage(savedPackage);
        }
        
        if (savedEmail) {
            const emailInput = document.getElementById('customer-email');
            if (emailInput) {
                emailInput.value = savedEmail;
            }
        }
    }
    
    saveSession() {
        // حفظ الجلسة في localStorage
        if (this.currentPackage) {
            localStorage.setItem('flix_selected_package', this.currentPackage.id);
        }
        
        const emailInput = document.getElementById('customer-email');
        if (emailInput && emailInput.value) {
            localStorage.setItem('flix_customer_email', emailInput.value);
        }
    }
    
    getDefaultPackages() {
        return [
            {
                id: 'basic_3m',
                name: {
                    en: '3 Months Plan',
                    ar: 'باقة 3 أشهر',
                    fr: 'Forfait 3 Mois',
                    es: 'Plan 3 Meses',
                    he: 'תוכנית ל-3 חודשים'
                },
                price: 25.00,
                currency: 'USD',
                duration: 3,
                features: [
                    '250+ Live Channels',
                    '5000+ VOD',
                    'Support All Devices',
                    '24/7 Support'
                ]
            },
            {
                id: 'standard_6m',
                name: {
                    en: '6 Months Plan',
                    ar: 'باقة 6 أشهر',
                    fr: 'Forfait 6 Mois',
                    es: 'Plan 6 Meses',
                    he: 'תוכנית ל-6 חודשים'
                },
                price: 45.00,
                currency: 'USD',
                duration: 6,
                features: [
                    'All Basic Features',
                    '300+ Live Channels',
                    '8000+ VOD',
                    'Premium Sports',
                    'Catch-up TV'
                ]
            },
            {
                id: 'premium_12m',
                name: {
                    en: '12 Months Plan',
                    ar: 'باقة 12 شهراً',
                    fr: 'Forfait 12 Mois',
                    es: 'Plan 12 Meses',
                    he: 'תוכנית ל-12 חודשים'
                },
                price: 70.00,
                currency: 'USD',
                duration: 12,
                features: [
                    'All Standard Features',
                    '400+ Live Channels',
                    '12000+ VOD',
                    '4K Content Available',
                    'Multi-screen (2 devices)',
                    'Priority Support'
                ]
            }
        ];
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.flixApp = new FlixIPTVApp();
});

// تصدير للاستخدام في ملفات أخرى
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FlixIPTVApp;
}