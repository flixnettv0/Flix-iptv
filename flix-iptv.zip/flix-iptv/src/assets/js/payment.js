/**
 * نظام معالجة الدفع لـ Flix-IPTV
 * يتكامل مع NOWPayments API ومعالجة Webhooks
 */

class PaymentProcessor {
    constructor() {
        this.apiBaseUrl = 'https://api.nowpayments.io/v1';
        this.orderCache = new Map();
        this.paymentStatuses = {
            'waiting': 'Waiting for payment',
            'confirming': 'Confirming payment',
            'confirmed': 'Payment confirmed',
            'sending': 'Sending to recipient',
            'partially_paid': 'Partially paid',
            'finished': 'Payment finished',
            'failed': 'Payment failed',
            'refunded': 'Payment refunded',
            'expired': 'Payment expired'
        };
        
        this.init();
    }
    
    init() {
        // التحقق من حالة الدفع في URL (للصفحات العائدة)
        this.checkReturnStatus();
        
        // إعداد مستمعات لتحديث حالة الدفع
        this.setupPaymentStatusPolling();
    }
    
    checkReturnStatus() {
        const urlParams = new URLSearchParams(window.location.search);
        const orderId = urlParams.get('order_id');
        const status = urlParams.get('status');
        
        if (orderId && status) {
            this.handleReturnPayment(orderId, status);
        }
    }
    
    async handleReturnPayment(orderId, status) {
        // التحقق من حالة الدفع عند العودة من بوابة الدفع
        try {
            const paymentStatus = await this.getPaymentStatus(orderId);
            
            if (paymentStatus.success) {
                if (paymentStatus.status === 'finished') {
                    // توجيه إلى صفحة النجاح
                    window.location.href = `/success.html?order_id=${orderId}`;
                } else if (['failed', 'expired'].includes(paymentStatus.status)) {
                    // توجيه إلى صفحة الإلغاء
                    window.location.href = `/cancel.html?order_id=${orderId}`;
                } else {
                    // استمر في الانتظار أو أظهر حالة
                    this.showPaymentStatus(paymentStatus);
                }
            }
        } catch (error) {
            console.error('Error checking payment status:', error);
        }
    }
    
    async createPayment(paymentData) {
        // إنشاء فاتورة دفع عبر NOWPayments API
        try {
            // أولاً، التحقق من صحة بيانات الدفع
            if (!this.validatePaymentData(paymentData)) {
                throw new Error('Invalid payment data');
            }
            
            // إعداد بيانات طلب API
            const requestData = {
                price_amount: paymentData.amount,
                price_currency: paymentData.currency,
                pay_currency: paymentData.cryptoCurrency || paymentData.currency,
                ipn_callback_url: `${window.location.origin}/api/payment-webhook`,
                order_id: paymentData.orderId,
                order_description: `Flix-IPTV: ${paymentData.packageName}`,
                success_url: `${window.location.origin}/success.html`,
                cancel_url: `${window.location.origin}/cancel.html`,
                customer_email: paymentData.customerEmail,
                is_fixed_rate: true,
                is_fee_paid_by_user: true
            };
            
            // إضافة معلومات إضافية للعملات المشفرة
            if (paymentData.cryptoCurrency) {
                requestData.pay_currency = paymentData.cryptoCurrency;
            }
            
            console.log('Creating payment with data:', requestData);
            
            // في البيئة الحقيقية، سيكون هذا استدعاء API فعلي
            // هنا نستخدم محاكاة للتنمية
            const mockResponse = this.mockCreatePayment(requestData);
            
            // حفظ بيانات الطلب في التخزين المحلي
            this.saveOrderToCache(paymentData.orderId, {
                ...paymentData,
                status: 'created',
                createdAt: Date.now()
            });
            
            return mockResponse;
            
        } catch (error) {
            console.error('Payment creation failed:', error);
            throw error;
        }
    }
    
    mockCreatePayment(requestData) {
        // محاكاة استجابة API لـ NOWPayments
        // في البيئة الحقيقية، استبدل هذا باستدعاء API فعلي
        
        const paymentId = 'mock_pay_' + Date.now();
        const paymentUrl = `https://nowpayments.io/payment/?iid=${paymentId}`;
        
        return {
            success: true,
            paymentId: paymentId,
            paymentUrl: paymentUrl,
            orderId: requestData.order_id,
            amount: requestData.price_amount,
            currency: requestData.price_currency,
            payCurrency: requestData.pay_currency,
            expiresAt: Date.now() + 3600000 // تنتهي بعد ساعة
        };
    }
    
    async getPaymentStatus(orderId) {
        // الحصول على حالة الدفع من NOWPayments API
        try {
            // في البيئة الحقيقية، استخدم:
            // const response = await fetch(`${this.apiBaseUrl}/payment/${orderId}`, {...});
            
            // محاكاة حالة الدفع
            await new Promise(resolve => setTimeout(resolve, 500));
            
            const order = this.getOrderFromCache(orderId);
            
            if (!order) {
                throw new Error('Order not found');
            }
            
            // محاكاة تغيير حالة عشوائية
            const statuses = ['waiting', 'confirming', 'finished', 'failed'];
            const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
            
            const mockStatus = {
                success: true,
                orderId: orderId,
                status: randomStatus,
                statusText: this.paymentStatuses[randomStatus],
                amount: order.amount,
                currency: order.currency,
                paidAmount: randomStatus === 'finished' ? order.amount : 0,
                createdAt: order.createdAt,
                updatedAt: Date.now()
            };
            
            // تحديث حالة الطلب في التخزين المحلي
            if (randomStatus === 'finished') {
                this.updateOrderStatus(orderId, 'completed');
            }
            
            return mockStatus;
            
        } catch (error) {
            console.error('Error fetching payment status:', error);
            throw error;
        }
    }
    
    async verifyWebhookSignature(signature, payload, ipnPin) {
        // التحقق من توقيع Webhook لـ NOWPayments
        // في NOWPayments، يتم التوقيع باستخدام HMAC-SHA512
        
        if (!signature || !payload || !ipnPin) {
            return false;
        }
        
        try {
            // في البيئة الحقيقية، استخدم:
            // const expectedSignature = crypto.createHmac('sha512', ipnPin).update(payload).digest('hex');
            // return expectedSignature === signature;
            
            // للتنمية، نقبل جميع التواقيع
            return true;
            
        } catch (error) {
            console.error('Webhook signature verification failed:', error);
            return false;
        }
    }
    
    validatePaymentData(paymentData) {
        // التحقق من صحة بيانات الدفع
        const requiredFields = [
            'packageId', 'amount', 'currency', 
            'customerEmail', 'paymentMethod', 'orderId'
        ];
        
        for (const field of requiredFields) {
            if (!paymentData[field]) {
                console.error(`Missing required field: ${field}`);
                return false;
            }
        }
        
        // التحقق من صحة البريد الإلكتروني
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(paymentData.customerEmail)) {
            console.error('Invalid email address');
            return false;
        }
        
        // التحقق من المبلغ
        if (paymentData.amount <= 0 || paymentData.amount > 10000) {
            console.error('Invalid amount');
            return false;
        }
        
        return true;
    }
    
    saveOrderToCache(orderId, orderData) {
        // حفظ بيانات الطلب في التخزين المحلي
        this.orderCache.set(orderId, orderData);
        localStorage.setItem(`order_${orderId}`, JSON.stringify(orderData));
        
        // أيضًا، إرسال إلى KV عبر API (في الخادم)
        this.sendOrderToServer(orderId, orderData);
    }
    
    getOrderFromCache(orderId) {
        // الحصول على بيانات الطلب من التخزين المحلي
        if (this.orderCache.has(orderId)) {
            return this.orderCache.get(orderId);
        }
        
        const storedOrder = localStorage.getItem(`order_${orderId}`);
        if (storedOrder) {
            const orderData = JSON.parse(storedOrder);
            this.orderCache.set(orderId, orderData);
            return orderData;
        }
        
        return null;
    }
    
    updateOrderStatus(orderId, status) {
        // تحديث حالة الطلب
        const order = this.getOrderFromCache(orderId);
        if (order) {
            order.status = status;
            order.updatedAt = Date.now();
            this.saveOrderToCache(orderId, order);
        }
    }
    
    async sendOrderToServer(orderId, orderData) {
        // إرسال بيانات الطلب إلى خادم Cloudflare Worker
        try {
            const response = await fetch('/api/save-order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    orderId: orderId,
                    orderData: orderData
                })
            });
            
            return await response.json();
        } catch (error) {
            console.error('Failed to send order to server:', error);
            // لا نرمي خطأ هنا لأن التطبيق يمكن أن يعمل بدونها
        }
    }
    
    setupPaymentStatusPolling() {
        // إعداد استطلاع دوري لتحديث حالة الدفع النشط
        // هذا مفيد للصفحات التي تنتظر تأكيد الدفع
        
        const pollInterval = setInterval(() => {
            const activeOrders = this.getActiveOrders();
            
            activeOrders.forEach(orderId => {
                this.checkAndUpdateOrderStatus(orderId);
            });
            
            // تنظيف الطلبات المنتهية
            this.cleanupCompletedOrders();
            
        }, 30000); // كل 30 ثانية
        
        // حفظ معرف الفاصل للتنظيف لاحقاً
        this.pollIntervalId = pollInterval;
    }
    
    getActiveOrders() {
        // الحصول على جميع الطلبات النشطة (غير المكتملة)
        const activeOrders = [];
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('order_')) {
                try {
                    const order = JSON.parse(localStorage.getItem(key));
                    if (order.status !== 'completed' && order.status !== 'failed') {
                        const orderId = key.replace('order_', '');
                        activeOrders.push(orderId);
                    }
                } catch (e) {
                    // تجاهل العناصر غير الصالحة
                }
            }
        }
        
        return activeOrders;
    }
    
    async checkAndUpdateOrderStatus(orderId) {
        // التحقق من حالة الطلب وتحديثه
        try {
            const status = await this.getPaymentStatus(orderId);
            
            if (status.success) {
                // تحديث واجهة المستخدم إذا كانت الصفحة مفتوحة
                this.updateUIWithStatus(orderId, status);
                
                // إذا اكتمل الدفع، إرسال إشعار
                if (status.status === 'finished') {
                    this.sendPaymentConfirmation(orderId);
                }
            }
        } catch (error) {
            console.error(`Failed to check status for order ${orderId}:`, error);
        }
    }
    
    updateUIWithStatus(orderId, status) {
        // تحديث واجهة المستخدم بحالة الدفع
        // هذا يعتمد على تصميمك، إليك مثال عام:
        
        const statusElements = document.querySelectorAll(`[data-order-id="${orderId}"]`);
        
        statusElements.forEach(element => {
            if (element.classList.contains('payment-status')) {
                element.textContent = status.statusText;
                element.className = `payment-status status-${status.status}`;
            }
        });
        
        // إظهار إشعار إذا اكتمل الدفع
        if (status.status === 'finished') {
            this.showPaymentCompleteNotification(orderId, status);
        }
    }
    
    showPaymentCompleteNotification(orderId, status) {
        // إظهار إشعار باكتمال الدفع
        const notification = document.createElement('div');
        notification.className = 'payment-notification success';
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-check-circle"></i>
                <div>
                    <strong>Payment Completed!</strong>
                    <p>Order ${orderId} has been confirmed. Your service is now active.</p>
                </div>
                <button class="notification-close">&times;</button>
            </div>
        `;
        
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #10b981;
            color: white;
            padding: 16px;
            border-radius: 8px;
            z-index: 10000;
            animation: slideIn 0.3s ease;
            max-width: 400px;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        `;
        
        document.body.appendChild(notification);
        
        // زر الإغلاق
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
        
        // الإغلاق التلقائي بعد 10 ثوان
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }
        }, 10000);
    }
    
    async sendPaymentConfirmation(orderId) {
        // إرسال تأكيد الدفع بالبريد الإلكتروني
        const order = this.getOrderFromCache(orderId);
        if (!order) return;
        
        try {
            // في البيئة الحقيقية، استدعِ API لإرسال البريد الإلكتروني
            const response = await fetch('/api/send-confirmation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    orderId: orderId,
                    customerEmail: order.customerEmail,
                    packageName: order.packageName,
                    amount: order.amount,
                    currency: order.currency
                })
            });
            
            const result = await response.json();
            console.log('Confirmation email sent:', result);
            
        } catch (error) {
            console.error('Failed to send confirmation email:', error);
        }
    }
    
    cleanupCompletedOrders() {
        // تنظيف الطلبات المكتملة القديمة
        const cutoffTime = Date.now() - (7 * 24 * 60 * 60 * 1000); // قبل أسبوع
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('order_')) {
                try {
                    const order = JSON.parse(localStorage.getItem(key));
                    
                    if (order.status === 'completed' && order.updatedAt < cutoffTime) {
                        // نقل إلى الأرشيف أو حذف
                        this.archiveOrder(key, order);
                        localStorage.removeItem(key);
                        this.orderCache.delete(key.replace('order_', ''));
                    }
                } catch (e) {
                    // تجاهل العناصر غير الصالحة
                }
            }
        }
    }
    
    archiveOrder(key, order) {
        // أرشفة الطلب (يمكن حفظه في KV على الخادم)
        console.log(`Archiving order: ${key}`);
        // في التطبيق الحقيقي، أرسل هذا إلى الخادم
    }
    
    generateActivationCode(orderId, macAddress) {
        // توليد كود تفعيل فريد بناءً على معرف الطلب وعنوان MAC
        const combined = `${orderId}:${macAddress}:${Date.now()}`;
        
        // استخدام hash بسيط (في التطبيق الحقيقي، استخدم خوارزمية أكثر أماناً)
        let hash = 0;
        for (let i = 0; i < combined.length; i++) {
            const char = combined.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // تحويل إلى 32-bit عدد صحيح
        }
        
        // تنسيق الكود بصيغة FLX-XXXX-XXXX-XXXX
        const code = `FLX-${Math.abs(hash).toString(36).substr(0, 4).toUpperCase()}-${
            Math.random().toString(36).substr(2, 4).toUpperCase()
        }-${
            Date.now().toString(36).substr(-4).toUpperCase()
        }`;
        
        // حفظ الكود في التخزين المحلي
        localStorage.setItem(`activation_${orderId}`, JSON.stringify({
            code: code,
            macAddress: macAddress,
            generatedAt: Date.now(),
            expiresAt: Date.now() + (30 * 24 * 60 * 60 * 1000) // 30 يوم
        }));
        
        return code;
    }
    
    getActivationCode(orderId) {
        // الحصول على كود التفعيل للطلب
        const stored = localStorage.getItem(`activation_${orderId}`);
        if (stored) {
            return JSON.parse(stored);
        }
        return null;
    }
    
    validateActivationCode(code, macAddress) {
        // التحقق من صحة كود التفعيل
        const regex = /^FLX-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
        
        if (!regex.test(code)) {
            return { valid: false, reason: 'Invalid code format' };
        }
        
        // البحث عن الكود في التخزين المحلي
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('activation_')) {
                const activation = JSON.parse(localStorage.getItem(key));
                
                if (activation.code === code) {
                    // التحقق من انتهاء الصلاحية
                    if (Date.now() > activation.expiresAt) {
                        return { valid: false, reason: 'Code expired' };
                    }
                    
                    // التحقق من عنوان MAC (إذا تم توفيره)
                    if (macAddress && activation.macAddress !== macAddress) {
                        return { valid: false, reason: 'MAC address mismatch' };
                    }
                    
                    return { 
                        valid: true, 
                        activation: activation,
                        orderId: key.replace('activation_', '')
                    };
                }
            }
        }
        
        return { valid: false, reason: 'Code not found' };
    }
    
    // دمج مع التطبيق الرئيسي
    integrateWithMainApp(app) {
        this.mainApp = app;
        
        // استبدال وظيفة processPayment في التطبيق الرئيسي
        if (app && typeof app.processPayment === 'function') {
            const originalProcessPayment = app.processPayment.bind(app);
            
            app.processPayment = async function() {
                // استخدام معالج الدفع الخاص بنا
                const paymentData = this.collectPaymentData();
                
                try {
                    const paymentResult = await window.paymentProcessor.createPayment(paymentData);
                    
                    if (paymentResult.success && paymentResult.paymentUrl) {
                        // حفظ بيانات الطلب
                        window.paymentProcessor.saveOrderToCache(
                            paymentData.orderId, 
                            { ...paymentData, status: 'pending' }
                        );
                        
                        // توجيه إلى صفحة الدفع
                        window.location.href = paymentResult.paymentUrl;
                    } else {
                        throw new Error('Failed to create payment');
                    }
                } catch (error) {
                    console.error('Payment processing failed:', error);
                    this.showError(`Payment failed: ${error.message}`);
                    this.hideLoadingState();
                }
            };
        }
    }
}

// تهيئة معالج الدفع
document.addEventListener('DOMContentLoaded', () => {
    window.paymentProcessor = new PaymentProcessor();
    
    // دمج مع التطبيق الرئيسي إذا كان موجوداً
    if (window.flixApp) {
        window.paymentProcessor.integrateWithMainApp(window.flixApp);
    }
});

// تصدير للاستخدام في ملفات أخرى
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PaymentProcessor;
}